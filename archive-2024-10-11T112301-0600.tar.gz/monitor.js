require('./config');
const fs = require('fs');
const path = require('path');
const cfonts = require('cfonts');
const { format } = require('util');
const { spawn } = require('child_process');

console.clear();

cfonts.say('BeetleJuice', {
	font: 'chrome',
	align: 'center',
	gradient: ['red', 'green']
});

cfonts.say('designed by: Hideki', {
	font: 'console',
	align: 'center',
	gradient: ['green', 'red']
});

function monitor() {
	try {
		console.start('...starting');

		let args = [path.join(__dirname, 'main.js'), ...process.argv.slice(2), '--pairing'];
		let cmd = spawn('/usr/local/bin/node', args, { stdio: ['inherit', 'inherit', 'inherit', 'ipc'] });

		cmd.on('message', (msg) => {
			switch(msg) {
				case 'reset':
				case 'restart': {
					cmd.kill();
					monitor();
				};
				break;

				case 'off':
				case 'shutdown': {
					cmd.kill();
					process.exit();
				}
				break;
			};
		});

		cmd.on('exit', (code, signal) => {
			if (code !== 0 && code !== null & signal !== 'SIGTERM') {
				cmd.kill();
				monitor();
			};
		});

		fs.watchFile(args[0], () => {
			fs.unwatchFile(args[0]);
			console.info('Se actualizo: ' + path.basename(args[0]));
			cmd.kill();
			monitor();
		});
	} catch(e) {
		console.error(format(e));
	};
};

monitor();