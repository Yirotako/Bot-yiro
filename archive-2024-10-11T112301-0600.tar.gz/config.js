const fs = require('fs');
const chalk = require('chalk');
const API = require('./lib/api');
const { format } = require('util');
const consola = require('consola');
const JsonBot = require('./bot.json');
const Plugin = require('./lib/plugins');
const Low = new (require('./lib/lowdb'));

/// REASSING GLOBAL ELEMETNS;
Object.assign(global, JsonBot);

/// GLOBAL CONSOLE & COLOR
global.console = {
	clear: console.clear,
	log: (...args) => consola.log(chalk.bold.rgb(0, 255, 196)(format(...args))),
	info: (...args) => consola.info(chalk.bold.rgb(255, 0, 200)(format(...args))),
	error: (...args) => consola.error(chalk.bold.rgb(255, 0, 0)(format(...args))),
	warn: (...args) => consola.error(chalk.bold.rgb(255, 100, 0)(format(...args))),
	start: (...args) => consola.start(chalk.bold.rgb(255, 240, 0)(format(...args))),
	success: (...args) => consola.success(chalk.bold.rgb(100, 255, 0)(format(...args)))
};

/// GLOBAL API;
global.api = new API('Vanitas - API', { URI: 'https://www.vanitas-api.online', APIKEY: bot.apikey });

/// GLOBAL COLDOWN;
const coldown = [];
global.isFilter = (sender) => coldown.includes(sender);
global.addFilter = (sender, ms = 5000) => {
	coldown.push(sender);

	setTimeout(() => {
		let index = coldown.indexOf(sender);

		if (index !== -1) {
			coldown.splice(index, 1);
		};
	}, ms);
};

/// GLOBAL JADIBOTS
global.jadibot = {};

/// GLOBAL MESSAGES & REACTION;
global.mess = {
	error: `🚩 Error: Se produjo un error al ejecutar el comando.`,
	verify: '🚩 Para usar este comando debe estar registrado en la base de datos.',
	admin: '🚩 Error: No se puede realizar la accion porque no es administrador.',
	nsfw: '🚩 Error: Este comando esta inhabilitado por ser nsfw (+18) pidele a un admin que lo active.',
	'admin-bot': '🚩 Error: El bot no puede realizar la accion por que no es administrador.',
	owner: `🚩 Error: Esta funcion esta solo disponibles para los desarrolladores: '${owner.map((v) => v.name).join('|')}'`,
	jadibot: '🚩 Error: Este es un sub bot, no tiene permitido ejecutar este comando.',
	'fake-bot': `${bot.name} by Nazi-Team`,
	'fake-image': `*⎔ Imagen descargada por ${bot.name}*`,
	'fake-video': `*⎔ Video descargado por ${bot.name}*`,
	'fake-audio': `*⎔ Audio descargado por ${bot.name}*`,
	'fake-gif': `*⎔ GiF descargado por ${bot.name}*`,
	'fake-meta': `*⎔ Metadatos obtenidos de la web por ${bot.name}*`,
	'fake-convert': `*⎔ Archivo convertido por ${bot.name}*`
};

global.react = {
	wait: '⏳',
	global: '✨',
	error: '❌',
	admin: '👑',
	oneview: '👀',
	owner: '🎩',
	clock: '⏱',
	lemon: '🍋‍🟩',
	silent: '🤫'
};

/// GLOBAL PLUGINS;
try {
	global.plugins = [];
	let plugin = new Plugin('messages/plugins');

	plugin.readPlugin(plugin.folder);
	plugin.watchPlugin(plugin.folder);
} catch(e) {
	console.error(format(e));
};

/// GLOBAL DATABASE;
try {
	let content = Low.read();

	if (content && Object.keys(content).length === 0) {
		global.db = { bot: {}, users: {}, chats: {}, stickers: {}, ...(content || {}) };

		Low.write(global.db);
	} else {
		global.db = content;
	}

	setInterval(async () => { if (global.db) await Low.write(global.db) }, 15_000);
} catch(e) {
	console.error(format(e));
};

/// AUTO SAVE CONFIG BOT;
setInterval(() => {
	for (let key in JsonBot) {
		let value = global[key];
		JsonBot[key] = value;

		fs.writeFileSync('bot.json', JSON.stringify(JsonBot, null, 2), 'utf-8');
	};
}, 30_000);