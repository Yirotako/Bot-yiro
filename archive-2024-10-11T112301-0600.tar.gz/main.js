require('./config.js');
const fs = require('fs');
const path = require('path');
const Pino = require('pino');
const readline = require('readline');
const WAConnect = require('./lib/whatsapp');
const { sms, msg } = require('./lib/simple');
const { Browsers, DisconnectReason, useMultiFileAuthState, makeCacheableSignalKeyStore, PHONENUMBER_MCC } = require('baileys');

let isPairing = process.argv.includes('--pairing');
let _readline = readline.createInterface({ input: process.stdin, output: process.stdout });
let question = (input) => new Promise((resolve) => _readline.question(input, resolve));

async function start() {
	const logger = Pino({ level: 'silent' }).child({ level: 'silent' });
	const { state, saveCreds } = await useMultiFileAuthState(bot['sesion-path']);

	let sock = new WAConnect({
		printQRInTerminal: !isPairing,
		logger,
		auth: {
			creds: state.creds,
			keys: makeCacheableSignalKeyStore(state.keys, logger)
		},
		generateHighQualityLinkPreview: true,
		version: [2, 3000, 1013451599],
		browser: Browsers.ubuntu('Chrome'),
		patchMessageBeforeSending: (message) => {
			const nativeFlowMessage = !!(message?.interactiveMessage);
			if (nativeFlowMessage) {
				message = {
					viewOnceMessage: {
						message: {
							messageContextInfo: {
								deviceListMetadataVersion: 2,
								deviceListMetadata: {}
							},
							...message
						}
					}
				};
			}
			return message;
		}
	});

	sock.ev.on('creds.update', saveCreds);

	sock.ev.on('connection.update', ({ qr, connection, lastDisconnect }) => {
		if (qr && !isPairing) console.info('Escanee el codigo QR para conectarse al bot:');

		if (connection === 'close') {
			if (!lastDisconnect) return;

			if (lastDisconnect?.error?.output?.statusCode !== 401) {
				start();
			} else {
				if (!bot['sesion-buffer']) {
					console.error('Error en la sesion, incie una nueva sesion por favor...');
					fs.rmSync(bot['sesion-path'], { recursive: true });
				} else {
					console.info('Restaurando copia de seguridad...');
					let session_path = path.join(__dirname, bot['sesion-path'], 'creds.json');
					let buffer = JSON.stringify(JSON.parse(Buffer.from(bot['sesion-buffer'], 'base64')));

					fs.writeFileSync(session_path, buffer, 'utf-8');
				}

				start();
			}
		} else if (connection === 'open') {
			_readline.close();
			console.info(`Se conecto a ${bot.name} correctamente.`);
		};
	});

	if (isPairing && !sock?.authState?.creds?.registered) {
		let phoneNumber;

		do {
			phoneNumber = await question('Ingrese su numero de telefono en este formato: 549xxxxxxx\nDigite su numero:');
			phoneNumber = phoneNumber.replace(/\D/g, '');

			if (!phoneNumber) await question('Digite su numero: ');
		} while (!Object.keys(PHONENUMBER_MCC).some((v) => phoneNumber.startsWith(v)));

		let code = await sock.requestPairingCode(phoneNumber);

		console.info(`Su codigo de conexion es: ${code.slice(0, 4)}-${code.slice(4, 8)}`);
	};

	sock.ev.on('messages.upsert', ({ type, messages }) => {
		for (let m of messages) {
			if (type === 'notify') {
				if (!m.message) continue;
//				if (m.key && m.key.fromMe) continue;
				if (m.key && m.key.remoteJid === 'status@broadcast') continue;

				require('./messages/upsert')(sock, sms(sock, m));
			};

			if (type === 'append') {
				if (!m.messageStubType) continue;
//				if (m.key && m.key.fromMe) continue;
				if (m.key && m.key.remoteJid === 'status@broadcast') continue;

				require('./messages/group')(sock, msg(sock, m));
			};
		};
	});

	return sock;
};

start();