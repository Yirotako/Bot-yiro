module.exports = {
	isGroup: true,
	isVerify: true,
	tag: 'Games',
	models: '%prefix%command',
	desc: 'El bot otorga un trabajo o mision y se le otorga una remuneracion.',
	cases: ['trabajo', 'trabajar', 'work', 'chamba', 'chambear'],
	run: async(m, { user, randomObj, msToTime }) => {
		let timeUser = parseInt(user.lastWork + 1800000);
		let timeNow = parseInt(Date.now() - user.lastWork);

		if (timeNow < 1800000) {
			await m.react(react.error);
			await m.reply(`🚩 Espere ${msToTime(timeUser - Date.now())} para volver a trabajar.`);
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let payWork = Math.round(10000 - (Math.random() * (5000 - 2000)));
		let work = randomObj(works);

		await m.react('👷');
		await m.reply(`${work} $${payWork}`);

		user.money += parseInt(payWork);
		user.lastWork += parseInt(Date.now());
	}
}

const works = [
	'Trabajas como cazador de dragones y te pagan:',
	'Eres el asesor del rey por 3 días y ganas:',
	'Conquistas una aldea junto a un ejercito y te llevas de botin: ',
	'Recolectas polvo de hadas y lo vendes en el mercado por:',
	'Eres un mago errante que ofrece sus servicios para resolver problemas místicos y ganas:',
	'Trabajas como espía en las sombras, obteniendo información valiosa para clientes secretos y recibes:',
	'Eres un comerciante de reliquias antiguas, compras y vendes artefactos místicos por:',
	'Sirves como guardián de los portales dimensionales, protegiendo el equilibrio entre los mundos y ganas:',
	'Eres un herrero experto en forjar armas legendarias y te pagan:',
	'Exploras ruinas perdidas en busca de tesoros olvidados y recibes:',
	'Formas parte de la guardia real, defendiendo el reino de amenazas externas y ganas:',
	'Eres un alquimista que destila elixires poderosos y los vende por:',
	'Viajas como comerciante de especias exóticas y ganas:',
	'Trabajas como médico especializado en curar enfermedades místicas y recibes:',
	'Eres un maestro de la caza de criaturas mágicas para colecciones privadas y ganas:',
	'Organizas torneos de magia y te llevas un porcentaje de las apuestas por:',
	'Eres un maestro de ceremonias en eventos místicos y ganas:',
	'Gestiones una taberna frecuentada por aventureros y obtienes ganancias por:',
	'Participas en la arena de gladiadores místicos y ganas:',
	'Eres un agricultor que cultiva plantas mágicas y vende productos especializados por:',
	'Sirves como guía en expediciones a tierras desconocidas y ganas:',
	'Trabajas como tatuador de runas místicas y cobras:',
	'Eres un diplomático que negocia tratados entre reinos y recibes:',
	'Investigas y cazas criaturas no muertas como cazador de vampiros y ganas:',
	'Eres el capitán de un barco pirata en busca de tesoros místicos y obtienes:',
	'Organizas eventos astrales y recibes donaciones por:',
	'Eres un erudito que traduce textos antiguos y ganas:',
	'Trabajas como arquitecto de ciudades encantadas y recibes:',
	'Eres el protector de un bosque sagrado y obtienes ofrendas por:',
	'Participas en carreras de grifos y ganas:',
	'Navegas como mercader de objetos mágicos y obtienes ganancias por:',
	'Trabajas como modista de prendas encantadas y cobras:',
	'Eres un arqueólogo que descubre artefactos perdidos y los vende por:',
	'Actúas como mediador entre criaturas mágicas y humanos y ganas:',
	'Trabajas como guía espiritual y recibes donaciones por:',
	'Eres un exorcista que libera lugares de entidades malignas y ganas:',
	'Participas en duelos mágicos como campeón y ganas:',
	'Eres un navegante de dimensiones paralelas y cobras por llevar a otros:',
	'Investigas y catalogas criaturas fantásticas y ganas:',
	'Trabajas como maestro de pociones para aldeas remotas y recibes:',
	'Eres el juez de un torneo de magia y recibes:',
	'Organizas expediciones a la luna en busca de minerales místicos y ganas:',
	'Eres un mensajero entre reinos lejanos y recibes:',
	'Trabajas como comandante de una unidad de élite contra bestias místicas y ganas:',
	'Eres un artista que crea ilusiones para entretenimiento y ganas:',
	'Participas en la caza de tesoros submarinos y obtienes ganancias por:',
	'Trabajas como guardián de un faro mágico y recibes:',
	'Eres un entrenador de bestias mitológicas para espectáculos y ganas:',
	'Sirves como embajador en el reino de las hadas y recibes:',
	'Exploras dimensiones alternativas en busca de conocimiento y ganas:'
];