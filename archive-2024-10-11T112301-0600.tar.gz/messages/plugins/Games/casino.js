module.exports = {
	isGroup: true,
	isVerify: true,
	tag: 'Games',
	models: '%prefix%command <monto>',
	desc: 'Juego de ruleta en casino. Tragamonedas.',
	cases: ['casino', 'tragamonedas'],
	run: async(m, { h2k, user, randomObj }) => {
		if (!m.args[0] || m.args[0]?.includes('.') || isNaN(m.args[0]) || m.args[0] < 100) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese una apuesta mayor a $100.\n\n*Ejemplo:* ${m.prefix+m.command} 600`);
			return;
		}

		if (m.args[0] > parseInt(user.money)) {
			await m.react(react.error);
			await m.reply('🚩 No posee esa cantidad para apostar.');
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let balance = parseInt(m.args[0]);
		let chance = (balance <= 10000) ? [5, 10, 10] : [10, 5, 5];
		chance = randomObj(chance);
		let failure = ['🍊 : 🍒 : 🍐', '🍒 : 🔔 : 🍊', '🍊 : 🍋 : 🔔', '🔔 : 🍒 : 🍐', '🔔 : 🍒 : 🍊', '🍊 : 🍋 : 🔔', '🍐 : 🍒 : 🍋', '🍊 : 🍒 : 🍒', '🔔 : 🔔 : 🍇', '🍌 : 🍒 : 🔔', '🍐 : 🔔 : 🔔', '🍊 : 🍋 : 🍒', '🍋 : 🍋 : 🍌', '🔔 : 🔔 : 🍇', '🔔 : 🍐 : 🍇'];
		let winner = ['🍇 : 🍇 : 🍇', '🍐 : 🍐 : 🍐', '🔔 : 🔔 : 🔔', '🍒 : 🍒 : 🍒', '🍊 : 🍊 : 🍊', '🍌 : 🍌 : 🍌'];
		let isFail = randomObj(failure);
		let isFail2 = randomObj(failure);
		let isWin = randomObj(winner);
		let message = '';

		switch (chance) {
			case 5:
				message = `❎ Has perdido $${h2k(balance)}`;
				user.money -= parseInt(balance);
			break;

			case 10:
				balance = parseInt(balance * 2);
				message = `🎉 ¡Felicidades! Has ganado $${h2k(balance)}`;
				user.money += parseInt(balance);
			break;
		}

		await m.reply(`\t\t\t*🎰 CASINO 🎰*\n\n╭─╼┥*${bot.name}*┝╾─╮\n╽ ┌──────────┐ ┃\n\t\t\t${isFail}\n┃ ├──────────┤ ┃\n\t\t\t${chance === 10 ? isWin : isFail}\n┃ ├──────────┤ ┃\n\t\t\t${isFail2}\n╿ └──────────┘ ╿\n╰──┥*${bot.name}*┠──╯\n\n${message}`);
		await m.react('🎰');
	}
}