module.exports = {
	isGroup: true,
	isVerify: true,
	tag: 'Games',
	models: '%prefix%command <monto>',
	desc: 'Inicia una partida de cartas, juego 21 BlackJack.',
	cases: ['blackjack', 'bj'],
	run: async(m, { h2k, chat, user }) => {
		let existRoom = Object.values(chat.games).find((i) => i.from === m.from && i.id === m.sender && i.name === 'blackjack');

		if (existRoom) {
			await m.react(react.error);
			await m.reply('Ya tiene una partida iniciada.');
			return;
		}

		if (!m.text) {
			await m.react(react.error);
			await m.reply(`Ingrese un monto para apostar 100(min) - 10000(max).\n\n*Ejemplo:* ${m.prefix+m.command} 5000`);
			return;
		}

		let balance = parseInt(m.args[0]);
		let money = user.money;

		if (isNaN(balance) || 100 > balance || 10000 < balance) {
			await m.react(react.error);
			await m.reply(`Ingrese un monto para apostar 100(min) - 10000(max).\n\n*Ejemplo:* ${m.prefix+m.command} 5000`);
			return;
		}

		if (balance > money || !money) {
			await m.react(react.error);
			await m.reply(`No posee esa cantidad para apostar.\n\n*• Su balance:* $${money} ${money > 999 ? `(${h2k(money)})` : ''}`);
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let pHand = [(drawRandomCard() - 1), drawRandomCard()];
		let bHand = [(drawRandomCard() - 1), drawRandomCard()];

		await m.react('🃏');
		await m.replyButton([{ type: 'reply', buttonText: 'Hit (Pedir)', buttonId: 'hit' }, { type: 'reply', buttonText: 'Stand (Irse)', buttonId: 'stand' }], { title: '\t\t\t*🃏 BlackJack 🃏*\n', body: `*➥ Mano de @${m.senderNumber}:* ${getHandValue(pHand)}\n*➥ Mano de ${bot.name}:* ---\n\n> Apuesta en juego: $${h2k(balance * 2)}\n\n`, footer: chat.footer });

		chat.games[m.sender] = {
			name: 'blackjack',
			id: m.sender,
			from: m.from,
			balance,
			pHand,
			bHand
		};
	}
}

/// GAME DESIGNED BY https://github.com/godinky/

function drawRandomCard() {
	let cardValues = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
	let randomIndex = Math.floor(Math.random() * cardValues.length);
	return cardValues[randomIndex];
};

function getHandValue(hand) {
	let result = hand.reduce((total, card) => total + card, 0);
	return result;
};