module.exports = {
	isGroup: true,
	isVerify: true,
	tag: 'Games',
	models: '%prefix%command <@user>',
	desc: 'Muestra el balance monetario de un usuario.',
	cases: ['balance', 'money', 'dinero', 'cash', 'guita'],
	run: async(m, { h2k }) => {
		await m.react(react.wait);

		let member = m.isQuoted ? m.quoted.sender : m.mentions[0] ? m.mentions[0] : m.sender;
		let user = db.users[member] || {};

		if (!user?.verify) {
			await m.react(react.error);
			await m.reply('🚩 El usuario no se encuentra registrado en la base de datos.');
			return;
		};

		await m.react(react.wait);

		addFilter(m.sender);

		let teks = `\t\t*${bot.name} Balance*\n\n`;
		teks += `│ ➼ *Usuario:* @${member.split('@')[0]}\n`;
		teks += `│ ➼ *Balance:* $${user.money} (${h2k(user.money)})\n`;
		teks += `│ ➼ *Rango:* ${user.premium ? 'V.I.P' : 'Free'}`;

		await m.reply(teks);
		await m.react(react.global);
	}
}