module.exports = {
	isGroup: true,
	isVerify: true,
	tag: 'Games',
	models: '%prefix%command <@user>',
	desc: 'Juego 3 en linea para 2 jugadores.',
	cases: ['tictactoe', 'ttt', 'xo'],
	run: async(m, { sock, chat, user, TicTacToe }) => {
		let existingRoom = Object.values(chat.games).find((room) => room.from === m.from && room.name === 'tictactoe' && [room?.game?.playerX, room?.game?.playerO].includes(m.sender));

		if (existingRoom) {
			await m.react(react.error);
			await m.reply('🚩 Ya estas en una partida en curso de XO.');
			return;
		};

		let member = m.isQuoted ? m.quoted.sender : m.mentions[0] ? m.mentions[0] : undefined;

		if (!member || [member].includes(m.botNumber) || !(member in db.users) || !db.users[member].verify) {
			await m.react(react.error);
			await m.reply('🚩 Mencione a un participante del grupo que este verificado para jugar.');
			return;
		};

		await m.react(react.wait);

		addFilter(m.sender);

		let msg = await m.reply(`@${member.split('@')[0]} fuiste invitado a una partida de XO por @${m.senderNumber}. Para aceptar responda 'SI' para rechazar responda 'NO'`);

		let [playerA, playerB] = [m.sender, member].sort(() => Math.random() - 0.5);
		let game = new TicTacToe(playerA, playerB);

		chat.games[m.sender] = {
			name: 'tictactoe',
			id: m.sender,
			from: m.from,
			playerAfk: [member],
			game
		};

		setTimeout(async() => {
			let room = Object.values(chat.games).find((room) => room.from === m.from && room.name === 'tictactoe' && room.id === m.sender);

			if (room?.playerAfk?.includes(member)) {
				await m.react(react.error);
				await m.reply('🚩 Se agoto el tiempo de espera del contrincante, se elimino la partida de XO.');

				delete chat.games[m.sender];
				await sock.sendMessage(m.from, { delete: msg.key });
			};
		}, 60000);
	}
}