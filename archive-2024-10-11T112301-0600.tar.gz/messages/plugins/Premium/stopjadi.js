module.exports = {
	isPremium: true,
	tag: 'Premium',
	models: '%prefix%command',
	desc: 'Detiene una sesion de jadibot.',
	cases: ['stopjadibot', 'sotopjadi', 'jadistop'],
	run: async(m, { sock, user }) => {
		if (!(m.sender in jadibot) || !jadibot[m.sender]?.start) {
			await m.react(react.error);
			await m.reply('🚩 No tiene ningun sub bot activo en este momento.');
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		if (sock.isJadibot) {
			jadibot[m.sender].shutdown = true;
			sock.ws.close();
			return;
		}

		await m.react(react.global);
		await m.reply('Se apago el jadibot con exito.');
	}
}