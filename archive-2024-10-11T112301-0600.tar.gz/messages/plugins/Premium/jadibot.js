const { sms } = require('../../../lib/simple');
const WAConnection = require('../../../lib/whatsapp');

const fs = require('fs');
const Pino = require('pino');
const path = require('path');
const crypto = require('crypto');
const qrcode = require('qrcode');
const { Browsers, useMultiFileAuthState, makeCacheableSignalKeyStore } = require('baileys');

const logger = Pino({ level: 'silent' }).child({ level: 'silent' });

__dirname = process.cwd();

let isPairing = false;
let count = 0;
let session;
let msg;

module.exports = {
	isPremium: true,
	tag: 'Premium',
	models: '%prefix%command <-pairing|-qrcode>',
	desc: 'Crea una sesion de un bot dentro del bot principal.',
	cases: ['jadibot', 'subbot', 'jadi'],
	run: async(m, { sock, user }) => {
		if (!m.text) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese una opcion de conexion para iniciar sesion.\n\n*Ejemplo:* ${m.prefix+m.command} -qrcode o -pairing`);
			return;
		}

		if (sock.isJadibot) {
			await m.react(react.error);
			await m.reply('🚩 Lo siento no puede crear una sesion en un sub bot. Solo en el bot oficial o principal.');
			return;
		}

		if (/^jadikey/gi.test(m.text)) {
			if (m.text !== user.jadibot.session.split('/').pop()) {
				await m.react(react.error);
				await m.reply('🚩 La sesion que ingreso no corresponde a ningun sub bot activo.');
				return;
			}

			if (jadibot[m.sender]?.start) {
				await m.react(react.global);
				await m.reply('🚩 El sub bot se encuentra activo en este momento no necesita encenderlo de nuevo.');
				return;
			}

			session = path.join(__dirname, 'tmp/jadibot', user.jadibot.session.split('/').pop());
			let _creds = path.join(session, 'creds.json');

			if (fs.existsSync(session)) {
				if (fs.existsSync(_creds)) {
					if (fs.readFileSync(_creds).toString() !== '') {
						user.jadibot.creds = Buffer.from(fs.readFileSync(_creds), 'utf-8').toString('base64');
					};
				};

				try { fs.rmSync(session, { recursive: true }); } catch(e) { console.error(e) };
			};

			let creds = Buffer.from(user?.jadibot?.creds, 'base64');
			fs.mkdir(session, { recursive: true }, () => {
				fs.writeFileSync(_creds, creds, 'utf-8');
			});
		} else {
			session = `${__dirname}/tmp/jadibot/jadikey-${crypto.randomBytes(7).toString('hex')}`;
		};

		if (!/^jadikey/gi.test(m.text)) {
			if (!jadibot[m.sender]?.status && !user?.jadibot?.creds) {
				if (m.text.startsWith('-pairing')) {
					isPairing = true;
				} else if (m.text.startsWith('-qrcode')) {
					isPairing = false;
				} else {
					await m.react(react.error);
					await m.reply(`🚩 Lo siento '${m.text}' no es una opcion disponible.\n\n*Ejemplo:* ${m.prefix+m.command} -qrcode o -pairing`);
					return;
				};
			} else {
				await m.react(react.error);
				await m.replyButton({ type: 'copy', buttonText: 'Key', buttonCopy: user.jadibot.session.split('/').pop() }, { title: '🚩 Lo siento usted ya tiene una sesion creada. Si quiere iniciar su bot use:', body: `${m.prefix+m.command} ${user.jadibot.session.split('/').pop()}\n`, footer: `> Jadibot by ${owner[0].name}` });
				return;
			};
		};

		await m.react(react.wait);

		addFilter(m.sender);

		async function start() {
			const { state, saveCreds } = await useMultiFileAuthState(session);

			let client = new WAConnection({
				logger,
				auth: {
					creds: state.creds,
					keys: makeCacheableSignalKeyStore(state.keys, logger)
				},
				generateHighQualityLinkPreview: true,
				version: [2, 3000, 1013451599],
				browser: Browsers.ubuntu('Chrome'),
				patchMessageBeforeSending: (message) => {
					const nativeFlowMessage = !!(message?.interactiveMessage);
					if (nativeFlowMessage) {
						message = {
							viewOnceMessage: {
								message: {
									messageContextInfo: {
										deviceListMetadataVersion: 2,
										deviceListMetadata: {}
									},
									...message
								}
							}
						};
					}
					return message;
				}
			});

			if (isPairing && !client.authState.creds.registered) {
				if (new Date() - count > 3 * 60 * 1 * 1000) {
					setTimeout(async() => {
						let number = m.senderNumber;
						let code = await client.requestPairingCode(number);
						code = `${code.slice(0, 4)}-${code.slice(4, 8)}`;
						await m.replyButton({ type: 'copy', buttonText: code, buttonCopy: code }, { title: `🚩 Copie el siguiente codigo y valla a la pantalla principal:\n`, body: 'Tres puntos > Dispositivos vinculados > vincular un dispositivo > vincular con el numero de telefono', footer: `> Jadi bot by ${owner[0].name}` });
						count++;
					}, 3000);
				} else {
					await m.react(react.error);
					await m.reply('🚩 Se agoto el tiempo (3 min) para conectarse al sub bot. Vuelva a ejecutar el comando para inciar una nueva sesion.');
					count = 0;
					fs.rmSync(session, { recursive: true });
					client?.ws?.close();
				};
			};

			client.isJadibot = jadibot[m.sender] ? true : false;

			client.ev.on('creds.update', saveCreds);

			client.ev.on('connection.update', async({ qr, connection, lastDisconnect }) => {
				if (!isPairing && qr) {
					if (count < 5) {
						qr = await qrcode.toDataURL(qr, { scale: 8 });
						let image = Buffer.from(qr.split(',')[0], 'base64');
						msg = await m.replyImg(image, { caption: `🚩 Escanee el codigo QR para inciar sesion en un subbot.\nTres puntos > Dispositivos vinculados > vincular un dispositivo > Escanear codigo QR`});
						count++;
						await m.delay(30000).then(() => sock.sendMessage(m.from, { delete: msg.key }));
					} else {
						await m.react(react.error);
						await m.reply('🚩 Se agoto los intentos (5) para inciar sesion. Vuelva a ejecutar el comando para inciar una nueva sesion.');
						count = 0;
						fs.rmSync(session, { recursive: true });
						client?.end();
					};
				};


				if (connection === 'close') {
					if (!lastDisconnect || (m.sender in jadibot) && jadibot[client.user.jid].shutdown) return;

					if (lastDisconnect?.error?.output?.statusCode !== 401) {
						await m.reply('🚩 El bot necesita reinciarse, reiniciando...');
						start();
					} else {
						if (fs.existsSync(session)) fs.rmSync(session, { recursive: true });
						await m.reply(`🚩 La sesion se daño, utilice ${m.prefix+m.command} para iniciar una nueva sesion.`);
						delete jadibot[m.sender];
						delete user.jadibot;
					};
				} else if (connection === 'open') {
					await m.react(react.global);
					await m.reply('Inicio de sesion exitoso conectado a: ' + bot.name);

					if (!jadibot[m.sender]) {
						user.jadibot = {
							...(user?.jadibot || {}),
							...client.user,
							name: await sock.getName(m.sender),
							session,
							creds: Buffer.from(fs.readFileSync(`${session}/creds.json`, 'utf-8')).toString('base64')
						};

						jadibot[m.sender] = {
							...user.jadibot,
							start: true
						};
					};

					if (jadibot[m.sender]?.start === false) jadibot[m.sender].start = true;

					if (!client.isJadibot) client.isJadibot = true;

					setInterval(() => {
						if (!user.premium && user?.jadibot?.session && (m.sender in jadibot)) {
							jadibot[m.sender].shutdown = true;
							sock.ws.close();

							fs.rmSync(user.jadibot.sesion, { recursive: true });
							delete db.bot[m.sender];
							delete jadibot[m.sender];
							delete user.jadibot;
						};
					}, 300000);
				};
			});

			client.ev.on('messages.upsert', async ({ type, messages }) => {
				for (let m of messages) {
					if (!m.message) continue;
					if (type !== 'notify') continue;
					if (m.key && m.key.remoteJid === 'status@broadcast') continue;

					require(path.join(__dirname, 'messages/upsert.js'))(client, sms(client, m));
				};
			});
		};

		return start();
	}
}