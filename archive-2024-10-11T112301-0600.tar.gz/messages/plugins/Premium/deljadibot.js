const fs = require('fs');

module.exports = {
	isPremium: true,
	tag: 'Premium',
	models: '%prefix%command',
	desc: 'Elimina una sesion de jadibot.',
	cases: ['deljadibot', 'deletejadi', 'jadidelete'],
	run: async(m, { sock, user }) => {
		if (!user?.jadibot?.session) {
			await m.react(react.error);
			await m.reply('🚩 No tiene ningun sub bot activo en este momento.');
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let jadibot = user.jadibot;

		fs.rmSync(jadibot.session, { recursive: true });

		delete user.jadibot;
		delete db.bot[m.sender];

		await m.react(react.global);
		await m.reply('Se elimino por completo la sesion de jadibot.');
	}
}