module.exports = {
	isNsfw: true,
	tag: 'NSFW',
	models: '%prefix%command',
	desc: 'Envia una imagen de hentai en modo NSFW (+18)',
	cases: ['hentai', 'hentai-nsfw'],
	run: async(m, { sock }) => {
		await m.react(react.wait);

		addFilter(m.sender);

		let image = await api.get('/api/anime/nsfw/hentai', {}, true);

		if (!image || !Buffer.isBuffer(image)) {
			await m.react(react.error);
			await m.reply(mess.error);
			return;
		}

		await m.replyImg(image, { caption: mess['fake-image'] });
		await m.react(react.global);
	}
}