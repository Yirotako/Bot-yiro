module.exports = {
	tag: 'Converter',
	models: '%prefix%command <text>',
	desc: 'Convierte un texto en voz (utiiliza la voz de tiktok).',
	cases: ['tts', 'texttovoice'],
	run: async(m, { base64ToBuffer }) => {
		if (!m.text || m.text.length >= 300) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un texto para convertir a voz no mayor a 300 caracteres.\n\n*Ejemplo:* ${m.prefix+m.command} Hola soy soy un bot de whatsapp, conectado a baileys, y estoy progrmado en JavaScrit.`);
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let { status, data } = await api.post('/api/tools/tts', { text: m.text });

		if (!status) {
			await m.react(react.error);
			await m.reply(mess.error);
			return;
		}

		let buffer = await base64ToBuffer(data);

		await m.replyAud(buffer);
		await m.react(react.global);
	}
}