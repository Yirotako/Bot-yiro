module.exports = {
	tag: 'Converter',
	models: '%prefix%command <text>',
	desc: 'Crea un sticker de texto con movimiento.',
	cases: ['attp'],
	run: async(m, { settings, getBuffer, videoToWebp }) => {
		if (!m.text) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un texto para convertirlo en sticker.\n\n*Ejemplo:* ${m.prefix+m.command} ¡Hola Mundo!`);
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let data = await api.get('/api/tools/attp', { text: m.text }, true);

		if (!data || !Buffer.isBuffer(data)) {
			await m.react(react.error);
			await m.reply(mess.error);
			return;
		}

		let sticker = await videoToWebp(data, false, settings.exif);

		await m.replyStik(sticker);
		await m.react(react.global);
	}
}