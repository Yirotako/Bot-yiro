module.exports = {
	tag: 'Converter',
	models: '%prefix%command <webp>',
	desc: 'Convierte un sticker con movimiento en video.',
	cases: ['tovid', 'avid', 'tomp4'],
	run: async(m, { v, sock, getRandom, base64ToBuffer }) => {
		if (!v.isMedia || !/\/webp$/.test(v.mime) || !v.isAnimated) {
			await m.react(react.error);
			await m.reply(`🚩 Mencione un sticker con movimiento para convertilo en video.\n\n*Ejemplo:* ${m.prefix+m.command} <webp>`);
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let media = await v.download();
		let { status, data, message } = await api.post('/api/tools/webp-to-mp4', { file: media, filename: getRandom('.webp') });

		if (!status) {
			await m.react(react.error);
			await m.reply(mess.error);
			return;
		}

		let buffer = await base64ToBuffer(data.split('base64,')[1]);

		await m.replyVid(buffer, { caption: mess['fake-convert'] });
		await m.react(react.global);
	}
}