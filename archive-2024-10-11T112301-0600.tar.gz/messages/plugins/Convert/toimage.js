module.exports = {
	tag: 'Converter',
	models: '%prefix%command <webp>',
	desc: 'Convierte un sticker fijo en imagen.',
	cases: ['toimg', 'aimg', 'topng'],
	run: async(m, { v, sock, getRandom, base64ToBuffer }) => {
		if (!v.isMedia || !/\/webp$/.test(v.mime) || v.isAnimated) {
			await m.react(react.error);
			await m.reply(`🚩 Mencione un sticker sin movimiento para convertilo en imagen.\n\n*Ejemplo:* ${m.prefix+m.command} <webp>`);
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let media = await v.download();
		let { status, data, message } = await api.post('/api/tools/webp-to-png', { file: media, filename: getRandom('.webp') });

		if (!status) {
			await m.react(react.error);
			await m.reply(mess.error);
			return;
		}

		let buffer = await base64ToBuffer(data.split('base64,')[1]);

		await m.replyImg(buffer, { caption: mess['fake-convert'] });
		await m.react(react.global);
	}
}