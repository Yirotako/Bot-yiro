const fs = require('fs');

module.exports = {
	tag: 'Converter',
	models: '%prefix%command <sticker>',
	desc: 'Cambia el nombre de un sticker por uno personalizado.',
	cases: ['take', 'exif', 'make'],
	run: async(m, { v, settings, writeExif, getRandom }) => {
		if (!m.text || !/webp$/.test(v.mime)) {
			await m.react(react.error);
			await m.reply(`🚩 Mencione un sticker junto con el nombre que le quiera dar.\n\n*Ejemplo:* ${m.prefix+m.command} Hideki|Isabella - Project`);
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let [packname, author] = m.text.split(/(\/|\||\\)/);
		let media = await v.download();
		let pathName = getRandom('.webp');

		fs.writeFileSync(pathName, media);

		let buffer = await writeExif(pathName, { packname, author, emojis: settings.exif.emojis });

		await m.react(react.global);
		await m.replyStik(buffer);

		fs.unlinkSync(pathName);
	}
}