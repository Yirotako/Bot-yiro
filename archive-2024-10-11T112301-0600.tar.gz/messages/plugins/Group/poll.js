const crypto = require('crypto');

module.exports = {
	isAdmin: true,
	tag: 'Group',
	models: '%prefix%command <name|opt1|opt2|opt3>',
	desc: 'Crea una encuesta con el bot etiquetando a todos en el grupo.',
	cases: ['encuesta', 'poll', 'getpoll'],
	run: async(m, { sock, group }) => {
		let a = [];
		let b = m.text.split(/\/|\||\-/);

		if (!b[0]) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un nombre a la encuesta para iniciarla.\n\n*Ejemplo:* ${m.prefix+m.command} ¿Programas en VSC?|Si|No|En otros`);
			return;
		};

		if (!b[1]) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese opciones a la encuesta para iniciarla.\n\n*Ejemplo:* ${m.prefix+m.command} ¿Programas en VSC?|Si|No|En otros`);
			return;
		};

		if (b[13]) {
			await m.react(react.error);
			await m.reply(`🚩 Ingreso demasiadas opciones para responder el limite es 12.`);
			return;
		};

		for (let i = 1; i < b.length; i++) {
			for (let v = i + 1; v < b.length; v++) {
				if (b[i] === b[v]) {
					await m.react(react.error);
					await m.reply(`🚩 La opcion ${i} se repite con la opcion ${v}. Intente no poner las mismas opciones.`);
					return;
				};
			};
			a.push(b[i]);
		};

		await m.react(react.wait);

		addFilter(m.sender);

		let teks = `\t\t\t*「 ✦ Encuesta by ${bot.name} ✦ 」*\n\n`;
		teks += `*Encuesta:* ${b[0]}`;

		let createPollMessage = {
			pollCreationMessage: {
				name: teks,
				selectableOptionsCount: 1,
				options: a.map((v) => ({ optionName: v })),
				contextInfo: {
					mentionedJid: group.participants.map((v) => sock.decodeJid(v.id)),
					remoteJid: m.from
				}
			},
			messageContextInfo: {
				messageSecret: crypto.randomBytes(32)
			}
		};

		await m.react(react.admin);
		await sock.relayMessage(m.from, createPollMessage, {});
	}
}