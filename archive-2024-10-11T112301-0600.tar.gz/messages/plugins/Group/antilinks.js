module.exports = {
	isGroup: true,
	isAdmin: true,
	isBotAdmin: true,
	tag: 'Group',
	models: '%prefix%command <true|false>',
	desc: 'Activa o desactiva el sitema antilinks de invitaciones.',
	cases: ['antilink', 'antilinks', 'antispam'],
	run: async(m, { chat, sock }) => {
		await m.react(react.wait);

		addFilter(m.sender);

		switch(m.query) {
			case 'true':
				if (chat.antilink) return m.reply('🚩 El antilink ya esta activo en el grupo.');

				chat.antilink = true;

				await m.react(react.admin);
				await m.reply('Se activo el antilink con exito.');
			break;

			case 'false':
				if (!chat.antilink) return m.reply('🚩 El antilink ya esta desactivado en el grupo.');

				chat.antilink = false;

				await m.react(react.admin);
				await m.reply('Se desactivo el antilink con exito.');
			break;

			default:
				await m.react(react.error);
				await m.replyButton({ type: 'list', buttonText: '📍 ¡Click Aqui! 📍', sections: [{ title: '', rows: [{ header: '• Desactivar antilink', title: '', description: 'Apaga el antilinks del grupo', id: `${m.prefix+m.command} false` }] }, { title: '', rows: [{ header: '• Activar antilink', title: '', description: 'Enciende el antilinks del grupo', id: `${m.prefix+m.command} true` }] }] }, { title: '🚩 ¿Desea activar o desactivar el antilinks del grupo?', body: `\n*• Estado:* ${chat.antilink ? 'Encendido' : 'Apagado'}`, footer: chat.footer });
		}
	}
}