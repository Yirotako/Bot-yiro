module.exports = {
	isGroup: true,
	isAdmin: true,
	isBotAdmin: true,
	tag: 'Group',
	models: '%prefix%command <image>',
	desc: 'Cambia la foto de perfil del grupo.',
	cases: ['icon', 'ppgroup', 'setppgp'],
	run: async(m, { v, sock }) => {
		if (!v.isMedia || !/image/.test(v.mime) || /webp/.test(v.mime)) {
			await m.react(react.error);
			await m.reply('🚩 Envie o mencione una imagen junto con el comando para hacerlo icono del grupo.');
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let image = await v.download();
		let { status } = await sock.updatePictureProfile(m.from, image);

		if (!status) {
			await m.react(react.error);
			await m.reply('🚩 Lo siento no se pudo actualizar el icono del grupo.');
			return;
		}

		await m.react(react.admin);
		await m.reply('Se actualizo el icono del grupo.');
	}
}