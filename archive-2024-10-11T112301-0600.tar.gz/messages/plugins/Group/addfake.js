const { PHONENUMBER_MCC } = require('baileys');
const prefijos = Object.keys(PHONENUMBER_MCC).map((v) => v);

module.exports = {
	isGroup: true,
	isAdmin: true,
	tag: 'Group',
	models: '%prefix%command +<prefijo>',
	desc: 'Agrega prefijos a una lista para evitar el ingreso al grupo de esos numeros.',
	cases: ['addfake', 'aggprefijo'],
	run: async(m, { chat }) => {
		if (!chat.antifake) {
			await m.react(react.error);
			await m.reply(`🚩 El sistema antifake debe estar activo en el grupo. Si desea activar el antifake use: ${m.prefix}antifake true`);
			return;
		};

		if (!m.args || !m.args[0]) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un prefijo para añadirlo a lista.\n\n*Ejemplo:* ${m.prefix+m.command} +54`);
			return;
		};

		let prefijo = m.args[0]?.replace('+', '');

		if (!prefijos.includes(prefijo)) {
			await m.react(react.error);
			await m.reply('🚩 Revise el prefijo, el que ingreso es incorrecto y no corresponde a ningun pais.');
			return;
		};

		prefijo = prefijo.startsWith('+') ? prefijo : '+' + prefijo;

		chat.fakelist.push(prefijo);

		await m.react(react.admin);
		await m.reply(`Se agrego el prefijo (${prefijo}) correctamente. Ahora todos los numero que empiezen con ${prefijo} no ingresaran al grupo.`);
	}
}