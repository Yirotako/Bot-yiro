module.exports = {
	isAdmin: true,
	tag: 'Group',
	models: '%prefix%command',
	desc: 'Califica a los usuarios mas participativos y a los menos participativos.',
	cases: ['topmsg', 'msgtop', 'toparticipate'],
	run: async(m, { sock, chat, group }) => {
		await m.react(react.wait);

		addFilter(m.sender);

		let users = group.participants.map((c) => sock.decodeJid(c.id));
		let icon = await sock.profilePictureUrl(m.from, 'image').catch(() => bot['render-template']);
		let topUsers = users.filter((v) => v !== m.botNumber).map((jid) => {
			if ((jid in db.users)) {
				let user = db.users[jid];
				let count = user?.countMsg || 0;

				return {
					jid,
					count
				}
			} else return ({ jid, count: 0 });
		})
		.sort((a, b) => b.count - a.count);

		let teks = '\t\t\t*✪ Ranking Activos ✪*\n\n';

		for (let i = 0; i < topUsers.length; i++) {
			teks += `*Top N° ${i+1}*\n`;
			teks += `*• User:* @${topUsers[i].jid.split('@')[0]}\n`;
			teks += `*• Total mensajes:* ${topUsers[i].count}\n\n`;
		};

		teks += `\n${chat.footer}`;

		await m.react(react.admin);
		await m.reply(teks, {
			ads: true,
			render: true,
			title: 'Los mas activos de ' + group.subject,
			body: 'Para subir en el Ranking sea activo...',
			image: icon
		});
	}
}