module.exports = {
	isGroup: true,
	isAdmin: true,
	isBotAdmin: true,
	tag: 'Group',
	models: '%prefix%command <text>',
	desc: 'Cambia el asunto (nombre) del grupo por el que el usuario ingrese.',
	cases: ['subject', 'setsubject', 'setitle'],
	run: async(m, { sock, group }) => {
		if (!m.text) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un nombre para cambiarle al grupo.\n\n*Ejemplo:* ${m.prefix+m.command} Hola Mundo`);
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let subject = group.subject;

		await sock.groupUpdateSubject(m.from, m.text);

		await m.react(react.admin);
		await m.reply(`Se actulizo el nombre del grupo: "${subject}" a "${m.text}"`);
	}
}