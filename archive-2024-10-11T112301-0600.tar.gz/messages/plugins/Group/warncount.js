module.exports = {
	isGroup: true,
	tag: 'Group',
	models: '%prefix%command <@user>',
	desc: 'Muestra la cantidad de warns (advertencias) de un usuario mencionado.',
	cases: ['warncount', 'countwarn'],
	run: async(m, { sock }) => {
		let member = m.isQuoted ? m.quoted.sender : m.mentions[0] ? m.mentions[0] : m.sender;

		let user = (member in db.users) ? db.users[member] : {};

		await m.react(react.wait);

		addFilter(m.sender);

		if (!user.warn || user.warn === 0) {
			await m.react(react.error);
			await m.reply('🚩 El usuario no posee advertencias.');
			return;
		}

		await m.react(react.global);
		await m.reply(`El usuario posee ${user.warn} advertencia(s).`);
	}
}