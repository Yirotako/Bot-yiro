module.exports = {
	isGroup: true,
	isAdmin: true,
	tag: 'Group',
	models: '%prefix%command <true|false>',
	desc: 'Activa o desactiva el sitema anti borrado de mensajes.',
	cases: ['antidelete', 'antiborrar', 'antidel'],
	run: async(m, { chat, sock }) => {
		await m.react(react.wait);

		addFilter(m.sender);

		switch(m.query) {
			case 'true':
				if (chat.antidelete) return m.reply('🚩 El antidelete ya esta activo en el grupo.');

				chat.antidelete = true;

				await m.react(react.admin);
				await m.reply('Se activo el antidelete con exito.');
			break;

			case 'false':
				if (!chat.antidelete) return m.reply('🚩 El antidelete ya esta desactivado en el grupo.');

				chat.antidelete = false;

				await m.react(react.admin);
				await m.reply('Se desactivo el antidelete con exito.');
			break;

			default:
				await m.react(react.error);
				await m.replyButton({ type: 'list', buttonText: '📍 ¡Click Aqui! 📍', sections: [{ title: '', rows: [{ header: '• Desactivar antidelete', title: '', description: 'Apaga el antidelete del grupo', id: `${m.prefix+m.command} false` }] }, { title: '', rows: [{ header: '• Activar antidelete', title: '', description: 'Enciende el antidelete del grupo', id: `${m.prefix+m.command} true` }] }] }, { title: '🚩 ¿Desea activar o desactivar el antidelete del grupo?', body: `\n*• Estado:* ${chat.antidelete ? 'Encendido' : 'Apagado'}`, footer: chat.footer });
		}
	}
}