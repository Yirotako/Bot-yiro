module.exports = {
	isGroup: true,
	isAdmin: true,
	isBotAdmin: true,
	tag: 'Group',
	models: '%prefix%command <close|open|lock|unlock>',
	desc: 'Cambia los ajustes del grupo.',
	cases: ['group', 'chat', 'settings'],
	run: async(m, { sock, group, chat }) => {
		await m.react(react.wait);

		addFilter(m.sender);

		switch(m.query) {
			case 'close':
				if (group.announce) return m.reply('🚩 El grupo ya esta cerrado.');
				await sock.groupSettingUpdate(m.from, 'announcement');
				await m.react(react.admin);
				await m.reply('Se cerro el grupo solo para administradores');
			break;

			case 'open':
				if (!group.announce) return m.reply('🚩 El grupo ya esta abierto.');
				await sock.groupSettingUpdate(m.from, 'not_announcement');
				await m.react(react.admin);
				await m.reply('Se abrio el grupo para todos los participantes');
			break;

			case 'lock':
				if (!group.restrict) return m.reply('🚩 Ya estan bloqueadas las configuraciones.');
				await sock.groupSettingUpdate(m.from, 'locked');
				await m.react(react.admin);
				await m.reply('Se bloquearon los ajustes del grupo solo para los administradores');
			break;

			case 'unlock':
				if (group.restrict) return m.reply('🚩 Ya estan desbloqueadas las configuraciones.');
				await sock.groupSettingUpdate(m.from, 'unlocked');
				await m.react(react.admin);
				await m.reply('Se desbloquearon los ajustes del grupo para todos los participantes');
			break;

			default:
				await m.react(react.error);
				await m.replyButton({
					type: 'list',
					buttonText: '📍 ¡Click Aqui! 📍',
					sections: [{
						title: '',
						rows: [{
							header: '• Abrir Grupo',
							title: '',
							description: 'Abre el grupo para todos los participantes del grupo.',
							id: `${m.prefix+m.command} open`
						}]
					}, {
						title: '',
						rows: [{
							header: '• Cerrar Grupo',
							title: '',
							description: 'Cierra el grupo solo para administradores.',
							id: `${m.prefix+m.command} close`
						}]
					}, {
						title: '',
						rows: [{
							header: '• Desbloquear Configuraciones',
							title: '',
							description: 'Abre las configuraciones para todos los participantes.',
							id: `${m.prefix+m.command} unlock`
						}]
					}, {
						title: '',
						rows: [{
							header: '• Bloquear Configuraciones',
							title: '',
							description: 'Cierra las configuraciones para los administradores.',
							id: `${m.prefix+m.command} lock`
						}]
					}]
				}, {
					title: '🚩 ¿Que configuracion desea cambiar?',
					body: `\n*• Grupo:* ${group.announce ? 'Cerrado' : 'Abierto'}\n*• Configuraciones:* ${group.restrict ? 'Desbloquedas' : 'Bloquedas'}`,
					footer: chat.footer
				});
		}
	}
}