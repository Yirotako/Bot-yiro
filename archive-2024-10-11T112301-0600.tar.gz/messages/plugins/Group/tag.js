module.exports = {
	isGroup: true,
	isAdmin: true,
	tag: 'Group',
	models: '%prefix%command <text>',
	desc: 'Menciona a todos los participantes del grupo dentro de un mensaje, de manera oculta.',
	cases: ['hidetag', 'mensaje', 'tag', 'msgtag'],
	run: async(m, { v, group, sock }) => {
		if (!v.msg || `${v.prefix+v.command}` === v.body) {
			await m.react(react.error);
			await m.reply(`🚩 Escriba o mencione un mensaje para etiquetar a todos.\n\n*Ejemplo:* ${m.prefix+m.command} Hola al grupo.`);
			return;
		};

		await m.react(react.wait);

		addFilter(m.sender);

		let users = group.participants;
		let participants = users.filter((v) => v.id !== m.botNumber).map((x) => sock.decodeJid(x.id));

		await m.react(react.admin);
		await m.replyForward(v, { caption: m.text ? m.text : v.text, mentions: [...participants, ...sock.parseMentions(v.text)] });
	}
}