const { readFileSync } = require('fs');

module.exports = {
	isGroup: true,
	isAdmin: true,
	isBotAdmin: true,
	tag: 'Group',
	models: '%prefix%command',
	desc: 'Elimina a un usuario al azar.',
	cases: ['ruletarusa', 'ruletaban', 'ruletabam'],
	run: async(m, { sock, group, resizeImg }) => {
		let participants = group.participants.filter((v) => ![m.botNumber, m.sender, ...m.admins].includes(v.id)).map((v) => sock.decodeJid(v.id));
		let member = participants[Math.floor(Math.random() * participants.length)];

		await m.reply('𝐐𝐔𝐄 𝐑𝐔𝐄𝐃𝐄 𝐋𝐀 𝐑𝐔𝐋𝐄𝐓𝐀');

		setTimeout(() => m.replyStik(readFileSync('ruleta.webp')), 1000);
		setTimeout(() => m.reply('¿𝐐𝐔𝐈𝐄𝐍 𝐒𝐄𝐑𝐀 𝐄𝐋𝐈𝐌𝐈𝐍𝐀𝐃𝐎?'), 4000);
		setTimeout(() => m.replyStik(readFileSync('ruleta2.webp')), 4000);
		setTimeout(async() => {
			await m.reply(` [🔫] 𝗘𝗟 𝗝𝗨𝗚𝗔𝗗𝗢𝗥 @${member.split('@')[0]}\n\n[🗡]𝙎𝙀𝙍𝘼 𝙀𝙇𝙄𝙈𝙄𝙉𝘼𝘿𝙊`);
			await sock.groupParticipantsUpdate(m.from, [member], 'remove');
		}, 12000);
	}
};