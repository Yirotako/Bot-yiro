module.exports = {
	isGroup: true,
	isAdmin: true,
	tag: 'Group',
	models: '%prefix%command <true|false>',
	desc: 'Activa o desactiva los comandos NSFW(+18).',
	cases: ['nsfw', 'nsfw+18', '18command'],
	run: async(m, { chat, sock }) => {
		await m.react(react.wait);

		addFilter(m.sender);

		switch(m.query) {
			case 'true':
				if (chat.nsfw) return m.reply('🚩 El antidelete ya esta activo en el grupo.');

				chat.nsfw = true;

				await m.react(react.admin);
				await m.reply('Se activo el antidelete con exito.');
			break;

			case 'false':
				if (!chat.nsfw) return m.reply('🚩 El antidelete ya esta desactivado en el grupo.');

				chat.nsfw = false;

				await m.react(react.admin);
				await m.reply('Se desactivo el antidelete con exito.');
			break;

			default:
				await m.react(react.error);
				await m.replyButton({ type: 'list', buttonText: '📍 ¡Click Aqui! 📍', sections: [{ title: '', rows: [{ header: '• Desactivar NSFW', title: '', description: 'Apaga los comandos NSFW del grupo', id: `${m.prefix+m.command} false` }] }, { title: '', rows: [{ header: '• Activar NSFW', title: '', description: 'Enciende los comandos NSFW del grupo', id: `${m.prefix+m.command} true` }] }] }, { title: '🚩 ¿Desea activar o desactivar el NSFW del grupo?', body: `\n*• Estado:* ${chat.nsfw ? 'Encendido' : 'Apagado'}`, footer: chat.footer });
		}
	}
}