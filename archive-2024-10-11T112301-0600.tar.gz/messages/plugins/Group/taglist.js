module.exports = {
	isGroup: true,
	isAdmin: true,
	tag: 'Group',
	models: '%prefix%command <text>',
	desc: 'Crea una lista con todos los participantes del grupo, y agrega un anuncio si el administrador lo desea.',
	cases: ['alltag', 'todos', 'tagall', 'foralltag'],
	run: async(m, { group, chat, sock }) => {
		await m.react(react.wait);

		addFilter(m.sender);

		let icon = await sock.profilePictureUrl(m.from, 'image').catch(_ => 'https://i.pinimg.com/originals/a1/21/d1/a121d1a908088da3a519a12a9a4b1a18.jpg');
		let participants = group.participants.filter((v) => v.id !== m.botNumber).map((x) => sock.decodeJid(x.id));

		let teks = `\t\t\t*[ Participantes de ${group.subject} ]*\n`;
		teks += `${m.text ? `\n*📢 Anuncio:* ${m.text}\n` : ''}`;

		for (let member of participants) {
			teks += `\n*•* @${member.split('@')[0]}`;
		}

		teks += `\n\n> *${chat.footer}*`;

		await m.react(react.admin);
		await m.reply(teks, {
			ads: true,
			render: true,
			title: 'Mencion a Todos',
			body: `Mencionados por: ${m.pushName}`,
			image: icon
		})
	}
}