module.exports = {
	isGroup: true,
	isAdmin: true,
	isBotAdmin: true,
	tag: 'Group',
	models: '%prefix%command <@user>',
	desc: 'Cambia los privilegios de un usuario a administrador.',
	cases: ['promote', 'admin'],
	run: async(m, { sock }) => {
		let member = m.isQuoted ? m.quoted.sender : m.mentions[0] ? m.mentions[0] : undefined;

		if (!member) {
			await m.react(react.error);
			await m.reply(`🚩 Mencione un usuario para darle administracion en el grupo.\n\n*Ejemplo:* ${m.prefix+m.command} @${m.senderNumber}`);
			return;
		};

		if (m.sender === member || m.botNumber === member) {
			await m.react(react.error);
			await m.reply('🚩 Lo siento no puedo darle admin a este usuario.');
			return;
		};

		if (m.admins.includes(member)) {
			await m.react(react.error);
			await m.reply('🚩 Este usuario ya es administrador.');
			return;
		};

		await m.react(react.wait);

		addFilter(m.sender);

		await sock.groupParticipantsUpdate(m.from, [member], 'promote')
		.then(async(update) => {
			for(let { status } of update) {
				if (status !== '200') {
					await m.react(react.error);
					await m.reply('🚩 Lo siento no se pudo darle administracion al usuario.');
				} else {
					await m.react(react.admin);
					await m.reply('Se le dio admin al usuario mencionado.');
				}
			}

		})
	}
}