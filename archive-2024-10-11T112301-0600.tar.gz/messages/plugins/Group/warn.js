module.exports = {
	isGroup: true,
	isAdmin: true,
	isBotAdmin: true,
	tag: 'Group',
	models: '%prefix%command <@user>',
	desc: 'Otorga un warn (advertencia) a un usuario mencionado.',
	cases: ['warn'],
	run: async(m, { sock }) => {
		let member = m.isQuoted ? m.quoted.sender : m.mentions[0] ? m.mentions[0] : undefined;

		if (!member || member === m.botNumber || member === m.sender) {
			await m.react(react.error);
			await m.reply(`🚩 Mencione un mensaje o a un usuario para darle un warn (advertencia).\n\n*Ejemplo:* ${m.prefix+m.command} @${m.senderNumber}`);
			return;
		}

		let user = (member in db.users) ? db.users[member] : {};

		await m.react(react.wait);

		addFilter(m.sender);

		if (user?.warn === 3) {
			await m.react(react.error);
			await m.reply('🚩 El usuario seleccionado llego al limte de warns (advertencias) permitidas (3). Se eliminara del grupo.');
			await m.delay(2500);
			await sock.groupParticipantsUpdate(m.from, [member], 'remove');
			db.users[member].warn = 0;
			return;
		}

		user.warn += 1;

		db.users[member] = user;

		await m.react(react.admin);
		await m.reply('Se le agrego 1 warn (advertencia) al usuario seleccionado.');
	}
}