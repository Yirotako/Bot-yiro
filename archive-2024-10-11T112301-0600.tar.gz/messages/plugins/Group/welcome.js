module.exports = {
	isGroup: true,
	isAdmin: true,
	tag: 'Group',
	models: '%prefix%command <true|false>',
	desc: 'Activa o desactiva la bienvenida.',
	cases: ['welcome'],
	run: async(m, { chat, sock }) => {
		await m.react(react.wait);

		addFilter(m.sender);

		switch(m.query) {
			case 'true':
				if (chat.welcome) return m.reply('🚩 La bienvenida ya esta activa en el grupo.');

				chat.welcome = true;

				await m.react(react.admin);
				await m.reply('Se activo la bienvenida del grupo.');
			break;

			case 'false':
				if (!chat.welcome) return m.reply('🚩 La bienvenida ya esta desactivada en el grupo.');

				chat.welcome = false;

				await m.react(react.admin);
				await m.reply('Se desactivo la bienvenida del grupo.');
			break;

			default:
				await m.react(react.error);
				await m.replyButton({
					type: 'list',
					buttonText: '📍 ¡Click Aqui! 📍',
					sections: [{
						title: '',
						rows: [{
							header: '• Desactivar bienvenida',
							title: '',
							description: 'Apaga la bienvenida del grupo',
							id: `${m.prefix+m.command} false`
						}]
					}, {
						title: '',
						rows: [{
							header: '• Activar bienvenida',
							title: '',
							description: 'Enciende la bienvenida del grupo',
							id: `${m.prefix+m.command} true`
						}]
					}]
				}, {
					title: '🚩 ¿Desea activar o desactivar la bienvenida del grupo?',
					body: `\n*• Estado:* ${chat.welcome ? 'Encendida' : 'Apagada'}`,
					footer: chat.footer
				});
		}
	}
}