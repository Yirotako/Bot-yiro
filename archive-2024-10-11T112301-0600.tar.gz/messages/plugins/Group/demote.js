module.exports = {
	isGroup: true,
	isAdmin: true,
	isBotAdmin: true,
	tag: 'Group',
	models: '%prefix%command <@user>',
	desc: 'Quita los privilegios de un usuario de administrador.',
	cases: ['demote', 'noadmin'],
	run: async(m, { sock }) => {
		let member = m.isQuoted ? m.quoted.sender : m.mentions[0] ? m.mentions[0] : undefined;

		if (!member) {
			await m.react(react.error);
			await m.reply(`🚩 Mencione un usuario para quitarle administracion en el grupo.\n\n*Ejemplo:* ${m.prefix+m.command} @${m.senderNumber}`);
			return;
		};

		if (m.sender === member || m.botNumber === member) {
			await m.react(react.error);
			await m.reply('🚩 Lo siento no puedo quitarle el admin a este usuario.');
			return;
		};

		if (!m.admins.includes(member)) {
			await m.react(react.error);
			await m.reply('🚩 Este usuario no es administrador.');
			return;
		};

		await m.react(react.wait);

		addFilter(m.sender);

		await sock.groupParticipantsUpdate(m.from, [member], 'demote')
		.then(async(update) => {
			for(let { status } of update) {
				if (status !== '200') {
					await m.react(react.error);
					await m.reply('🚩 Lo siento no se pudo quitar la administracion al usuario.');
				} else {
					await m.react(react.admin);
					await m.reply('Se le quito admin al usuario mencionado.');
				}
			}

		})
	}
}