module.exports = {
	isGroup: true,
	isAdmin: true,
	isBotAdmin: true,
	tag: 'Group',
	models: '%prefix%command <true|false>',
	desc: 'Activa o desactiva el sitema antifakes de prefijos.',
	cases: ['antifake', 'antifakes', 'antiprefijo'],
	run: async(m, { chat, sock }) => {
		await m.react(react.wait);

		addFilter(m.sender);

		switch(m.query) {
			case 'true':
				if (chat.antifake) return m.reply('🚩 El antifake ya esta activo en el grupo.');

				chat.antifake = true;

				await m.react(react.admin);
				await m.reply(`Se activo el antifake con exito. Si desea agregar prefijos a la lista use: ${m.prefix}addfake +<prefijo>`);
			break;

			case 'false':
				if (!chat.antifake) return m.reply('🚩 El antifake ya esta desactivado en el grupo.');

				chat.antifake = false;

				await m.react(react.admin);
				await m.reply('Se desactivo el antifake con exito.');
			break;

			default:
				await m.react(react.error);
				await m.replyButton({ type: 'list', buttonText: '📍 ¡Click Aqui! 📍', sections: [{ title: '', rows: [{ header: '• Desactivar antifake', title: '', description: 'Apaga el antifake del grupo', id: `${m.prefix+m.command} false` }] }, { title: '', rows: [{ header: '• Activar antifake', title: '', description: 'Enciende el antifake del grupo', id: `${m.prefix+m.command} true` }] }] }, { title: '🚩 ¿Desea activar o desactivar el antifake del grupo?', body: `\n*• Estado:* ${chat.antifake ? 'Encendido' : 'Apagado'}`, footer: chat.footer });
		}
	}
}