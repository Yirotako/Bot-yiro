module.exports = {
	tag: 'Other',
	models: '%prefix%command <id>',
	desc: 'Elimina los datos guardados de los juegos del bot.',
	cases: ['unreg', 'unverify'],
	run: async(m, { user, getRandomID }) => {
		if (!m.text) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese su id para confirmar que desea borrar los datos guardados.\n\n*Ejemplo:* ${m.prefix+m.command} ${getRandomID(10, true)}`);
			return;
		};

		if (m.text.toLowerCase() !== user.id.toLowerCase()) {
			await m.react(react.error);
			await m.reply('🚩 El id que ingreso no corresponde al registrado. Revise su perfil.');
			return;
		};

		await m.react(react.wait);

		addFilter(m.sender);

		let keys = Object.keys(user).slice(11);

		for (let key of keys) {
			delete user[key];
		};

		user.verify = false;

		await m.react(react.global);
		await m.reply('Se eliminaron sus registros correctamente.');
	}
}