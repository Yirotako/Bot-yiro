module.exports = {
	tag: 'Other',
	models: '%prefix%command <name>',
	desc: 'Registro para usuarios que quieran utilizar los juegos del bot.',
	cases: ['register', 'verify', 'reg'],
	run: async(m, { sock, user, getRandomID }) => {
		if (user.verify) {
			await m.react(react.error);
			await m.reply(`🚩 Usted ya esta registrado en la base de datos. Si desea eliminar su registro use: ${m.prefix}unreg ${user.id}`);
			return;
		};

		if (!m.text) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un nombre para guardarlo en la base de datos.\n\n*Ejemplo:* ${m.prefix+m.command} ${bot.name}`);
			return;
		};

		await m.react(react.wait);

		addFilter(m.sender);

		let message;
		let code = getRandomID(5, true);
		let captcha = await api.get('/api/tools/captcha', { code: code }, true);
		let regex = new RegExp(code, 'i');
		let count = 0;

		message = await m.replyImg(captcha, { caption: `🚩 Responda a este mensaje con el codigo que ve en la imagen para verificar que no es un bot.\n\n> *Intentos:* 3\n> *Tiempo:* 3 min` });

		while(true) {
			if (count === 3) {
				user.verify = false;
				user.name = m.pushName;

				await m.react(react.error);
				await m.reply('🚩 Se agotaron los intentos (3) de verificacion. Si quiere registrarse de nuevo incie el comando nuevamente.');
				break;
			};

			try {
				let v = await sock.waitMessage({
					from: m.from,
					sender: m.sender,
					timeout: 180000
				});

				if (regex.test(v.body)) {

					user.id = getRandomID(10, true);
					user.name = m.text;
					user.verify = true;
					user.money = parseInt(1000);

					break;
				} else {
					count++;

					if (count < 3) {
						await m.react(react.error);
						await m.reply(`🚩 Codigo incorrecto. Intente nuevamente.\n\n> *Intentos:* ${3-count}`);
					}

					continue;
				}
			} catch(e) {
				if (e.includes('timeout')) {
					await m.react(react.error);
					await m.reply('🚩 Se agoto el tiempo para responde la Captcha. Intente nuevamente mas tarde.');
					break;
				};
			};
		};

		if (user.verify) {
			await m.react(react.global);
			await m.reply('*Verificacion exitosa.*\n\nYa puede usar los juegos del bot.');
		};

		await sock.sendMessage(m.from, { delete: message.key });
	}
}