module.exports = {
	tag: 'Search',
	models: '%prefix%command <text>',
	desc: 'Busca videos en Pinterest',
	cases: ['pinvid', 'pinv', 'vpin'],
	run: async(m, { chat, randomObj }) => {
		if (!m.text) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un termino para buscar en Pinterest.\n\n*Ejemplo 1:* ${m.prefix+m.command} Vanitas`);
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let { status, data, message } = await api.get('/search/pinterest-video', { text: m.text });

		if (!status) {
			await m.react(react.error);
			await m.reply(`🚩 Error al realizar la busqueda.`);
			return;
		}

		let { media } = randomObj(data);

		await m.react(react.global);
		await m.replyButton({
			type: 'list',
				buttonText: '📥 ¡Opciones! 📥',
				sections: [{
					title: '────────────※ ·❆· ※────────────',
					rows: [{
						header: '',
						title: '🎥 Siguiente Video 🎥',
						description: 'Siguiente resultado de video.',
						id: `${m.prefix+m.command} ${m.text}`
					}]
				}, {
					title: '────────────※ ·❆· ※────────────',
					rows: [{
						header: '',
						title: '🔎 Busqueda en Imagen 🔍',
						description: 'Realiza una busqueda similar pero en imagen.',
						id: `${m.prefix}pinterest ${m.text}`
					}]
				}]
			}, {
				title: mess['fake-video'],
				footer: chat.footer
			}, {
				media: true,
				response: media.url
			});
	}
}