module.exports = {
	tag: 'Search',
	models: '%prefix%command <text o url>',
	desc: 'Busca o descarga musica de soundcloud.',
	cases: ['applemusic', 'apple', 'appmusic'],
	run: async(m, { chat, bytesToSize, msToTime, resizeImg, webpToImgURL }) => {
		if (m.text && !m.bodyUrl) {
			await m.react(react.wait);

			addFilter(m.sender);

			let { status, data, message } = await api.get('/search/applemusic', { text: m.text });

			if (!status) {
				await m.react(react.error);
				await m.reply(`🚩 Error al realizar la busqueda.`);
				return;
			}

			let teks = '\t\t\t*「 ✦ Search AppleMusic ✦ 」*\n\n';
			let sections = [];

			for (let i = 0; i < data.length; i++) {
				if (!data || !data[i]) continue;
				sections.push({
					title: '────────────※ ·❆· ※────────────',
					rows: [{
						header: `Resultado N°${i+1}`,
						title: `Titulo: ${data[i].title}`,
						description: `Autor: ${data[i].artist}`,
						id: `${m.prefix}applemusic ${data[i].url}`
					}]
				})
			}

			teks += `*❏ Busqueda:* ${m.text}\n`;
			teks += `*❏ Resultados:* ${sections.length}`;

			let jpegThumnail = await webpToImgURL(data[0].thumb);

			await m.react(react.global);
			await m.replyButton({
				type: 'list',
				buttonText: '📥 ¡Descargas! 📥',
				sections
			}, {
				title: teks,
				footer: `\n${chat.footer}`
			}, {
				media: true,
				response: jpegThumnail
			});

		} else if (m.bodyUrl && /music\.apple\.com\//i.test(m.bodyUrl)) {
			await m.react(react.wait);

			addFilter(m.sender);

			let { status, data, message } = await api.get('/download/applemusic', { url: m.bodyUrl });

			if (!status) {
				await m.react(react.error);
				await m.reply(`🚩 Error al realizar la descarga.`);
				return;
			}

			let { image } = await resizeImg(data.thumb, 200);
			let teks = '\t\t\t*「 ✦ Download AppleMusic ✦ 」*\n\n';

			teks += `*• Titulo:* ${data.title}\n`;
			teks += `*• Tipo:* ${data.type}\n`;
			teks += `*• Duracion:* ${msToTime(data.duration)}\n`;
			teks += `*• Peso:* ${bytesToSize(data.size)}\n`;
			teks += `\n> ${chat.footer}`;

			await m.react(react.global);
			await m.replyDoc(data.link, { caption: teks, jpeg: image.toString('base64'), filename: `${data.title}.mp3`, mimetype: 'audio/mpeg' });
		} else {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un termino para buscar en AppleMusic o una url para descargar.\n\n*Ejemplo 1:* ${m.prefix+m.command} amorfoda bad bunny\n*Ejemplo 2:* ${m.prefix+m.command} https://music.apple.com/id/album/xxxxx/xxxxx`);
		}
	}
}