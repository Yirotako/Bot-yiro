module.exports = {
	tag: 'Search',
	models: '%prefix%command <text>',
	desc: 'Busca o descarga multimedia de Pinterest.',
	cases: ['pinterest', 'pindl', 'pin'],
	run: async(m, { chat, randomObj }) => {
		if (m.text && !m.bodyUrl) {
			await m.react(react.wait);

			addFilter(m.sender);

			let { status, data, message } = await api.get('/search/pinterest', { text: m.text });

			if (!status) {
				await m.react(react.error);
				await m.reply(`🚩 Error al realizar la busqueda.`);
				return;
			}

			let { media } = randomObj(data);

			await m.react(react.global);
			await m.replyButton({
				type: 'list',
				buttonText: '📥 ¡Opciones! 📥',
				sections: [{
					title: '────────────※ ·❆· ※────────────',
					rows: [{
						header: '🖼️ Siguiente Imagen 🖼️',
						title: '',
						description: '',
						id: `${m.prefix+m.command} ${m.text}`
					}]
				}, {
					title: '────────────※ ·❆· ※────────────',
					rows: [{
						header: '🔎 Busqueda en Video 🔍',
						title: '',
						description: '',
						id: `${m.prefix}pinvid ${m.text}`
					}]
				}]
			}, {
				title: mess['fake-image'],
				footer: chat.footer
			}, {
				media: true,
				response: media.url
			});
		} else if (m.bodyUrl && /pinterest\.com|pin\.it/i.test(m.bodyUrl)) {
			await m.react(react.wait);

			addFilter(m.sender);

			let { status, data, message } = await api.get('/download/pinterest', { url: m.bodyUrl });

			if (!status) {
				await m.react(react.error);
				await m.reply(`🚩 Error al realizar la descarga.`);
				return;
			}

			let media = Array.isArray(data.media) ? data.media : [data.media];

			for (let { url, type } of media) {
				switch (type) {
					case 'gif':
						await m.replyDoc(url, { caption: mess['fake-gif'], filename: `Pinterest-${Date.now()}.gif`, mimetype: 'image/gif' });
					break;

					case 'image':
						await m.replyImg(url, { caption: mess['fake-image'] });
					break;

					case 'video':
						await m.replyVid(url, { caption: mess['fake-video'], gif: false });
					break;
				}
			}

			await m.react(react.global);
		} else {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un termino para buscar en Pinterest.\n\n*Ejemplo 1:* ${m.prefix+m.command} Vanitas\n*Ejemplo2:* ${m.prefix+m.command} https://ar.pinterest.com/pin/xxxx`);
		}
	}
}