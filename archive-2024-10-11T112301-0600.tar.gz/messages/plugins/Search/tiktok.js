module.exports = {
	tag: 'Search',
	models: '%prefix%command <text o url>',
	desc: 'Descarga o busca, videos e imagenes de TikTok.',
	cases: ['tiktok', 'ttdl', 'tt'],
	run: async(m, { h2k, chat, runtime, webpToImgURL }) => {
		if (m.text && !m.bodyUrl) {
			await m.react(react.wait);

			addFilter(m.sender);

			let { status, data, message } = await api.get('/search/tiktok', { text: m.text });

			if (!status) {
				await m.react(react.error);
				await m.reply(`🚩 Error al realizar la busqueda.`);
				return;
			}

			let teks = '\t\t\t*「 ✦ TikTok Search ✦ 」*\n\n';
			let sections = [];

			for (let i = 0; i < data.length; i++) {
				if (!data || !data[i]) continue;
				sections.push({
					title: `⎔ Resultado: ${i+1}`,
					rows: [{
						header: '',
						title: data[i].title,
						description: `Autor: ${data[i].author} | Duracion: ${runtime(data[i].duration)} | Likes: ${h2k(data[i].liked)}`,
						id: `${m.prefix+m.command} ${data[i].link}`
					}]
				})
			}

			teks += `*❏ Busqueda:* ${m.text}\n`;
			teks += `*❏ Resultados:* ${sections.length}`;

			let jpegThumnail = await webpToImgURL(data[0].thumbnail);

			await m.react(react.global);
			await m.replyButton({
				type: 'list',
				buttonText: '📥 ¡Descargas! 📥',
				sections
			}, {
				title: teks,
				footer: chat.footer
			}, {
				media: true,
				response: jpegThumnail
			});
		} else if (m.bodyUrl && /(vm|www)\.tiktok\.com\//i.test(m.bodyUrl)) {
			await m.react(react.wait);

			addFilter(m.sender);

			let { status, data, message } = await api.get('/download/tiktok', { url: m.bodyUrl });

			if (!status) {
				await m.react(react.error);
				await m.reply(`🚩 Error al realizar la descarga.`);
				return;
			}

			let result = data.images ? (Array.isArray(data.images) ? data.images : [data.images]) : Array.isArray(data.video) ? data.video : [data.video];

			for (let link of result) {
				if (data.images) await m.replyImg(link, { caption: mess['fake-image'] });
				else await m.replyVid(link, { caption: mess['fake-video'] });
			}

			await m.react(react.global);
		} else {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un termino o una url para continuar.\n\n*Ejemplo 1:* ${m.prefix+m.command} Vanitas no carte\n*Ejemplo 2:* ${m.prefix+m.command} https://vm.tiktok.com/ZM6y8hwsM/`);
		}
	}
}