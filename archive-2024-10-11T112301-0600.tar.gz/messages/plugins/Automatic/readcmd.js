const { proto, areJidsSameUser, generateWAMessage } = require('baileys');

module.exports = {
	tag: 'Automatic',
	desc: 'Comando automatico para leer los stickers.',
	start: async(m, { sock, v }) => {
		if (!/webp$/.test(m.mime)) return;
		if (!(m.sha256String in db.stickers)) return;

		let { command, prefix } = db.stickers[m.sha256String];
		let mentions = [m.isQuoted ? m.quoted.sender : m.sender];
		let text = bot.usedPrefix ? prefix + command : command;

		let msg = await generateWAMessage(m.from, { text, mentions }, { userJid: m.sender, quoted: v });

		msg.key = m.key;

		let sms = {
			type: 'notify',
			messages: [proto.WebMessageInfo.fromObject(msg)]
		};

		sock.ev.emit('messages.upsert', sms);
	}
}