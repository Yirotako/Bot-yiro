module.exports = {
	isGroup: true,
	tag: 'Automatic',
	desc: 'Comando suplemento de tictactoe.',
	start: async(m, { chat, user, h2k }) => {
		let room = Object.values(chat.games).find((room) => room.name === 'tictactoe' && room.from === m.from && [room.game.playerO, room.game.playerX].includes(m.sender));

		if (!room) return;

		if (room.playerAfk.includes(m.sender) && /^si/i.test(m.body)) {
			room.playerAfk = [];

			let data = room.game.render().map((i) => room.game.emojiMap[i]);
			let board = `${data.slice(0, 3).join(' *┃* ')}\n${data.slice(3, 6).join(' *┃* ')}\n${data.slice(6).join(' *┃* ')}`;
			let message = `*Turno de:* @${room.game.currentTurn.split('@')[0]} (${(room.game.currentTurn === room.game.playerX ? '❌' : '⭕')})`;

			await m.reply(`*❌⭕️ TicTacToe ❌⭕️*\n\n${board}\n\n${message}`);
		};

		if (room.playerAfk.includes(m.sender) && /^no/i.test(m.body)) {
			room.playerAfk = [];

			await m.reply('🚩 El contrincante no acepto la partida de XO.', { mentions: [room.id] });

			delete chat.games[room.id];
		};

		if (/^[1-9]{1}/.test(m.body) && [room.game.playerO, room.game.playerX].includes(m.sender)) {
			let position = (parseInt(m.body) - 1);
			let status = room.game.playMove(m.sender, position);

			if (status === 500 || status === 404 || status === 400) return m.reply({ 500: '🚩 No es su turno', 404: '🚩 Posicion invalida', 400: '🚩 Posicion ocupada' }[status]);

			let isWin = (room.game.status === 201);
			let isTie = (room.game.status === 500);

			let winner = room.game.getWinner();
			let data = room.game.render().map((i) => room.game.emojiMap[i]);
			let board = `${data.slice(0, 3).join(" *┃* ")}\n${data.slice(3, 6).join(" *┃* ")}\n${data.slice(6).join(" *┃* ")}`;
			let message = isWin ? `*@${winner.split("@")[0]} es el ganador se lleva:* ${h2k(10000)}` : isTie ? `*Es un empate los dos se llevan:* ${h2k(5000)}` : `*Turno de:* ${(room.game.currentTurn === room.game.playerX ? "❌" : "⭕")} (@${room.game.currentTurn.split("@")[0]})`;

			await m.reply(`*❌⭕️ TicTacToe ❌⭕️*\n\n${board}\n\n${message}`);

			if (isWin || isTie) {
				if (isWin) db.users[winner].money += parseInt(10000);
				if (isTie) {
					db.users[room.game.playerO].money += parseInt(5000);
					db.users[room.game.playerX].money += parseInt(5000);
				};

				delete chat.games[room.id];
			};
		};
	}
}