module.exports = {
	tag: 'Automatic',
	desc: 'Conteo de mensajes del grupo por usuario.',
	start: async(m, { user }) => {
		if (m.type === 'protocolMessage' || m.isMe) return;

		this.user = this.user ? this.user : {};

		if (!(m.sender in this.user)) this.user[m.sender] = { lastMsg: m.messageTimestamp };

		let member = this.user[m.sender]

		if (m.messageTimestamp - member.lastMsg > 3) {
			user.countMsg += 1;
		};
	}
}