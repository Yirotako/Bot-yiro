module.exports = {
	tag: 'Automatic',
	desc: 'Comando automatico para leer los stickers.',
	start: async(m, { chat, user, sock }) => {
		if (!chat.antidelete) return;

		if (sock.messages.length > 500) sock.messages = [];

		if (m.type !== 'protocolMessage' && m.message && !m.isMe) sock.messages.push({ key: m.key, message: m.message });

		if (m.type === 'protocolMessage') {
			let msg = sock.messages.find((index) => index.key.id === m.msg.key.id);

			if (!msg) return;

			let quoted = { key: msg.key, message: { extendedTextMessage: { text: '🚩 Este mensaje fue eliminado 🚩' }}};

			await m.replyForward(msg, { quoted });

			let index = sock.messages.indexOf(msg);

			if (index !== -1) {
				sock.messages.splice(index, 1);
			};

			user.countMsg -= 1;
		};
	}
}