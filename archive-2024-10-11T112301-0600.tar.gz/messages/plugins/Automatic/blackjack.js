module.exports = {
	isGroup: true,
	tag: 'Automatic',
	desc: 'Comando suplemento de 21 Blackjack.',
	start: async(m, { h2k, chat, user }) => {
		let room = Object.values(chat.games).find((game) => game.from === m.from && game.id === m.sender && game.name === 'blackjack');

		if (!room) return;

		if (/^hit/i.test(m.body)) {
			room.pHand.push(drawRandomCard());

			let pHand = getHandValue(room.pHand);
			let bHand = getHandValue(room.bHand);
			let balance = parseInt(room.balance);

			if (bHand <= 10) room.bHand.push(drawRandomCard());

			if (pHand > 21) {
				await m.react(react.error);
				await m.reply(`\t\t\t*🃏 BlackJack 🃏*\n\n*➥ Mano de @${m.senderNumber}:* ${pHand}\n*➥ Mano de ${bot.name}:* ${bHand}\n\n*Has perdido $${h2k(balance)}*`);

				user.money -= balance;

				delete chat.games[room.id];
			} else {
				await m.replyButton([{ type: 'reply', buttonText: 'Hit (Pedir)', buttonId: 'hit' }, { type: 'reply', buttonText: 'Stand (Irse)', buttonId: 'stand' }], { title: '\t\t\t*🃏 BlackJack 🃏*\n', body: `*➥ Mano de @${m.senderNumber}:* ${pHand}\n*➥ Mano de ${bot.name}:* ---\n\n> Apuesta en juego: $${h2k(balance * 2)}\n\n`, footer: chat.footer });
				await m.react('🃏');
			};
		};

		if (/^stand/i.test(m.body)) {
			let pHand = getHandValue(room.pHand);
			let bHand = getHandValue(room.bHand);
			let balance = parseInt(room.balance);

			if (bHand > pHand) {
				await m.react(react.error);
				await m.reply(`\t\t\t*🃏 BlackJack 🃏*\n\n*➥ Mano de @${m.senderNumber}:* ${pHand}\n*➥ Mano de ${bot.name}:* ${bHand}\n\n*Has perdido $${h2k(balance)}*`);

				user.money -= balance;
			} else if (pHand > bHand) {
				await m.react('🎉');
				await m.reply(`\t\t\t*🃏 BlackJack 🃏*\n\n*➥ Mano de @${m.senderNumber}:* ${pHand}\n*➥ Mano de ${bot.name}:* ${bHand}\n\n*Has ganado $${h2k(balance * 2)}*`);

				user.money += balance;
			} else {
				await m.react('❎');
				await m.reply(`\t\t\t*🃏 BlackJack 🃏*\n\n*➥ Mano de @${m.senderNumber}:* ${pHand}\n*➥ Mano de ${bot.name}:* ${bHand}\n\n*Es un empate nadie gana.*`);
			};

			delete chat.games[room.id];
		};
	}
}

/// GAME DESIGNED BY https://github.com/godinky/

function drawRandomCard() {
	let cardValues = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
	let randomIndex = Math.floor(Math.random() * cardValues.length);
	return cardValues[randomIndex];
};

function getHandValue(hand) {
	let result = hand.reduce((total, card) => total + card, 0);
	return result;
};