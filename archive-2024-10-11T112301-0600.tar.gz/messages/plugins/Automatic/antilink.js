let regex = /(https?:\/\/)?((chat\.)?whatsapp\.com\/(?:(invite|channel)\/)?([0-9A-Za-z]{20,24})|discord(?:app)?\.(com|gg)\/invite\/|t\.me\/|wa\.me\/)/gi;

module.exports = {
	isGroup: true,
	tag: 'Automatic',
	desc: 'Sistema antilink para evitar spam y mas.',
	start: async(m, { chat, sock }) => {
		if (!chat.antilink) return;
		if (!regex.test(m.body)) return;

		if (/chat\.whatsapp\.com/.test(m.body)) {
			let code = await sock.groupInviteCode(m.from);
			if (m.body.includes('chat.whatsapp.com/' + code)) return;
		};

		if (m.isOwner || m.isAdmin || m.isMe) return;

		await m.reply('Se detecto un link de invitacion en el grupo. Se eliminara el mensaje y su emisor tambien.');
		await m.delete();

		await m.delay(2000);
		await sock.groupParticipantsUpdate(m.from, [m.sender], 'remove');
	}
}