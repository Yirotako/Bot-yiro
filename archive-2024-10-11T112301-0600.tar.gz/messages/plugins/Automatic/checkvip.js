const fs = require('fs');

module.exports = {
	tag: 'Automatic',
	desc: 'Comando automatico para leer los stickers.',
	start: async(m, { user, sock }) => {
		if (!user?.premium) return;

		let now = parseInt(Date.now());
		let dateNow = parseInt(now - user.premiumTimestamp);
		let daysCount = parseInt(dateNow / (1000 * 60 * 60 * 24));

		if (daysCount >= 30) {
			await m.react(react.oneview);
			await m.reply('🚩 Su suscripcion al "V.I.P" ha finalizado, sus benefios premium seran revocados.');

			user.premiumTimestamp = 0;
			user.premium = false;

			if (user?.jadibot?.session) {
				let sesion = user.jadibot.session;

				fs.rmSync(sesion, { recursive: true });

				delete db.bot[m.sender];
				delete jadibot[m.sender];
				delete user.jadibot;
			};
		};
	}
}