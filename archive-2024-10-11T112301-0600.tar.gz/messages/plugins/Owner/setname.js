module.exports = {
	isOwner: true,
	tag: 'Owner',
	models: '%prefix%command <text>',
	desc: 'Cambia el nombre del bot.',
	cases: ['setname', 'namebot', 'changename'],
	run: async(m, { settings, sock }) => {
		let isBussines = await sock.getBusinessProfile(m.botNumber);

		if (!m.text) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un nombre para cambiarle al bot.\n\n*Ejemplo:* ${m.prefix+m.command} Nazi - Bot Beta`);
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		bot.name = m.text.trim();

		if (isBussines) {
			await m.react(react.owner);
			await m.reply('Su sesion esta iniciada en un WhatsApp Bussines asi que solo se cambiara de manera local el nombe, aguarde...');
			await m.delay(25000);

			settings.name = m.text.trim();

			await m.reply('El nombre del bot cambio a: ' + bot.name);
		} else {
			
			await sock.updateProfileName(m.text.trim());

			settings.name = m.text.trim();

			await m.reply('El nombre del bot cambio a: ' + bot.name);
		}

		await m.react(react.owner);
	}
}