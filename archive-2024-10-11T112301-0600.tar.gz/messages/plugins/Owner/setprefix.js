module.exports = {
	isOwner: true,
	tag: 'Owner',
	models: '%prefix%command <prefijo>',
	desc: 'Agrega un prefijo a la lista de prefijos del bot.',
	cases: ['setprefix', 'setpre', 'preset'],
	run: async(m, { settings }) => {
		if (!m.text || /[a-z0-9]/gi.test(m.text)) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un simbolo para agregar como prefijo.\n\n*Ejemplo:* ${m.prefix+m.command} !`);
			return;
		}

		if (bot.prefix.includes(m.args[0])) {
			await m.react(react.error);
			await m.reply(`🚩 El prefijo que ingreso ya esta dentro de los prefijos: ${bot.prefix}`);
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		bot.prefix.push(m.args[0]);

		await m.react(react.owner);
		await m.reply(`Se agrego un prefijo nuevo: ${m.args[0]}`);
	}
}