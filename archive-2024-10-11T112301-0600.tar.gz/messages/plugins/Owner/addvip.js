module.exports = {
	isOwner: true,
	tag: 'Owner',
	models: '%prefix%command <@user>',
	desc: 'Otorga V.I.P a un usuario seleccionado.',
	cases: ['vip', 'addvip'],
	run: async(m, { sock }) => {
		let member = m.isQuoted ? m.quoted.sender : m.mentions[0] ? m.mentions[0] : undefined;
		let owners = owner.map((v) => v.number + '@s.whatsapp.net');

		if (!member) {
			await m.react(react.error);
			await m.reply(`🚩 Mencione a un usuario del grupo para darle "V.I.P".\n\n*Ejemplo:* ${m.prefix+m.command} @${m.botNumber.split('@')[0]}`);
			return;
		};

		if (member === m.sender || member === m.botNumber || owners.includes(member)) {
			await m.react(react.error);
			await m.reply('🚩 ¡El numero seleccionado no se le puede dar "V.I.P"!');
			return;
		};

		await m.react(react.wait);

		addFilter(m.sender);

		let user = (member in db.users) ? db.users[member] : {};

		if (user?.premium) {
			await m.react(react.error);
			await m.reply(`🚩 ¡Este usuario ya es "V.I.P"!`);
			return;
		};

		user.premium = true;
		user.premiumTimestamp = parseInt(Date.now());

		db.users[member] = user;

		await m.react(react.owner);
		await m.reply('¡Se le dio "V.I.P" con exito al usuario mencionado!');
	}
}