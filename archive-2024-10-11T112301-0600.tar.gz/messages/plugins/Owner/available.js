module.exports = {
	isOwner: true,
	tag: 'Owner',
	models: '%prefix%command <command> -gp',
	desc: 'Habilita un comando para poder usarlo.',
	cases: ['available', 'activar'],
	run: async(m, { chat, settings }) => {
		if (!m.args || !m.args[0]) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un comando para habiltar el plugin.\n\n*Ejemplo:* ${m.prefix+m.command} play`);
			return;
		}

		let plugin = plugins.find((v) => Array.isArray(v.cases) && v.cases.includes(m.args[0].toLowerCase()));

		if (!plugin) {
			await m.react(react.error);
			await m.reply(`🚩 No se encontro ningun comando llamado: '${m.args[0]}'. Revise el menu.`);
			return;
		};

		let onlygp = m.args.includes('-gp');

		if (onlygp && chat.unavailable.includes(plugin.name) && settings.unavailable.includes(plugin.name)) {
			await m.react(react.error);
			await m.reply(`🚩 No se encontro ese plugin deshabilitado.`);
			return;
		};

		let index = onlygp ? chat.unavailable.indexOf(plugin.name) : settings.unavailable.indexOf(plugin.name);

		if (index !== -1) {
			onlygp ? chat.unavailable.splice(index, 1) : settings.unavailable.splice(index, 1);

			await m.react(react.owner);
			await m.reply(`Se activo el plugin '${plugin.name}' correctamente.`);
		} else {
			await m.react(react.error);
			await m.reply(`🚩 Lo siento no se puedo habiltar el plugin. No se encontro ninguno deshabilitado`);
		};
	}
}