module.exports = {
	isOwner: true,
	tag: 'Owner',
	models: '%prefix%command <image>',
	desc: 'Cambia la foto de perfil del bot.',
	cases: ['ppbot', 'setppbot', 'setpp'],
	run: async(m, { v, sock }) => {
		if (!v.isMedia || !/image/.test(v.mime) || /webp/.test(v.mime)) {
			await m.react(react.error);
			await m.reply('🚩 Envie o mencione una imagen junto con el comando para hacerla foto de perfil.');
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let image = await v.download();
		let { status } = await sock.updatePictureProfile(m.botNumber, image);

		if (!status) {
			await m.react(react.error);
			await m.reply('🚩 Lo siento no se pudo actualizar la foto de mi perfil.');
			return;
		}

		await m.react(react.owner);
		await m.reply('Se actualizo mi foto de perfil.');
	}
}