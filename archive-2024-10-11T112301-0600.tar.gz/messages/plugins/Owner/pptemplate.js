const FormData = require('form-data');
const { fromBuffer } = require('file-type');
const { default: axios } = require('axios');

module.exports = {
	isOwner: true,
	tag: 'Owner',
	models: '%prefix%command <media>',
	desc: 'Cambia el template del menu.',
	cases: ['template', 'changetmp', 'rendertemplate'],
	run: async(m, { v, chat, bytesToSize }) => {
		if (!/^image\//.test(v.mime) || /\/webp$/.test(v.mime)) {
			await m.react(react.error);
			await m.reply(`🚩 Mencione una imagen para agregar al template del menu.\n\n*Ejemplo:* ${m.prefix+m.command} <imagen>`);
			return;
		};

		if (v.size > 5242880) {
			await m.react(react.error);
			await m.reply(`🚩 El elemento multimedia (${bytesToSize(v.size)}) que intenta subir supera el limite permitido de 5MB`);
			return;
		};

		let media = await v.download();
		let url = await Telegraph(media);

		chat['render-template'] = url;

		await m.react(react.global);
		await m.reply('Se acutalizo la imagen del menu correctamente.');
	}
}

function Telegraph(media) {
	return new Promise(async(resolve, reject) => {
		try {
			let form = new FormData();
			let { ext, mime } = await fromBuffer(media);

			form.append('file', media, `tmp-${Date.now()}.${ext}`);

			let { status, statusText, data } = await axios('https://telegra.ph/upload', {
				method: 'POST',
				data: form
			});

			if (status !== 200) return reject(new Error(statusText));

			if (data.error) return reject(new Error(data.error + '\n\nMedia no compatible.'));

			if (data) {
				resolve('https://telegra.ph' + data[0].src);
			}
		} catch(e) {
			reject(e);
		}
	})
}