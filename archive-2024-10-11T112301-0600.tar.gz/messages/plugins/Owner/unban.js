module.exports = {
	isOwner: true,
	tag: 'Owner',
	models: '%prefix%command <@user>',
	desc: 'Desbanea a un usuario seleccionado del uso del bot',
	cases: ['unban', 'userunban'],
	run: async(m, { sock }) => {
		let member = m.isQuoted ? m.quoted.sender : m.mentions[0] ? m.mentions[0] : undefined;
		let owners = owner.map((v) => v.number + '@s.whatsapp.net');

		if (!member) {
			await m.react(react.error);
			await m.reply(`🚩 Mencione a un usuario del grupo para desbanearlo. (Solo lo desbanea para poder usar el bot)\n\n*Ejemplo:* ${m.prefix+m.command} @${m.botNumber.split('@')[0]}`);
			return;
		}

		if (member === m.sender || member === m.botNumber || owners.includes(member)) {
			await m.react(react.error);
			await m.reply('🚩 ¡El numero seleccionado no puede ser desbaneado!')
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let user = (member in db.users) ? db.users[member] : {};

		if (!user?.ban) {
			await m.react(react.error);
			await m.reply(`🚩 ¡Este usuario no esta baneado!`);
			return;
		}

		user.ban = false;
		user.banReason = '';

		db.users[member] = user;

		await m.react(react.owner);
		await m.reply('¡Se desbaneo con exito al usuario mencionado!');
	}
}