module.exports = {
	isOwner: true,
	tag: 'Owner',
	models: '%prefix%command <packname|autor>',
	desc: 'Cambia el exif de los stickers creados por el bot.',
	cases: ['setexif', 'editexif'],
	run: async(m, { bot, sock }) => {
		let [packname, author] = m.text.split(/\/|\||\-|\_|\|/);

		if (!packname || !author) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un nombre de paquete y un autor.\n\n*Ejemplo:* ${m.prefix+m.command} Ronin|Hideki`);
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		bot.exif.packName = packname;
		bot.exif.packPublish = author;

		await m.react(react.owner);
		await m.reply('Se actualizo el exif de los stickers.');
	}
}