module.exports = {
	isOwner: true,
	tag: 'Owner',
	models: '%prefix%command <command> -gp',
	desc: 'Deshabilita un comando para no poder usarlo.',
	cases: ['unavailable', 'desactivar'],
	run: async(m, { chat, settings }) => {
		if (!m.args || !m.args[0]) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un comando para inhabiltar el plugin completamente.\n\n*Ejemplo:* ${m.prefix+m.command} play`);
			return;
		}

		let plugin = plugins.find((v) => Array.isArray(v.cases) && v.cases.includes(m.args[0].toLowerCase()));

		if (!plugin) {
			await m.react(react.error);
			await m.reply(`🚩 No se encontro ningun comando llamado: '${m.args[0]}'. Revise el menu.`);
			return;
		};

		let onlygp = m.args.includes('-gp');

		if (onlygp && chat.unavailable.includes(plugin.name) || settings.unavailable.includes(plugin.name)) {
			await m.react(react.error);
			await m.reply(`🚩 El plugin ${plugin.name} ya esta deshabilitado.`);
			return;
		}

		 if(onlygp) chat.unavailable.push(plugin.name);
		 else settings.unavailable.push(plugin.name);

		await m.react(react.owner);
		await m.reply(`Se desactivo el plugin '${plugin.name}' correctamente ${onlygp ? 'para este grupo' : ''}.`.trim());
	}
}