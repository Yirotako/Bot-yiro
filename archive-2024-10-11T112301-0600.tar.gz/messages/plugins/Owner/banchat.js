module.exports = {
	isOwner: true,
	tag: 'Owner',
	models: '%prefix%command <true|false>',
	desc: 'Enciende o apaga el sistemad de baneo de chats.',
	cases: ['mute', 'banchat', 'mutechat'],
	run: async(m, { sock, chat }) => {
		await m.react(react.wait);

		addFilter(m.sender);

		switch(m.query) {
			case 'true':
				if (chat.mute) return m.reply('🚩 El chat ya se encuentra muteado.');

				chat.mute = true;

				await m.react(react.owner);
				await m.reply('El chat se muteo con exito.');
			break;

			case 'false':
				if (!chat.mute) return m.reply('🚩 El chat no se encuentra muteado.');

				chat.mute = false;

				await m.react(react.owner);
				await m.reply('El chat se desmuteo con exito.');
			break;

			default:
				await m.react(react.error);
				await m.replyButton({
					type: 'list',
					buttonText: '📍 ¡Click Aqui! 📍',
					sections: [{
						title: '',
						rows: [{
							header: '• Desactivar Muteo',
							title: 'Mute Off',
							description: 'Apaga el muteo del chat para que el bot lea los msj...',
							id: `${m.prefix+m.command} false`
						}]
					}, {
						title: '',
						rows: [{
							header: '• Activar Muteo',
							title: 'Mute On',
							description: 'Enciende el muteo del chat para que el bot no lea los msj...',
							id: `${m.prefix+m.command} true`
						}]
					}]
				}, {
					title: `🚩 ¿Desea activar o desactivar el muteo de chat?`,
					body: `\n*• Estado:* ${chat.mute ? 'Muteado' : 'Desmuteado'}`,
					footer: chat.footer
				});
		}
	}
}