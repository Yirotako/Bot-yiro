module.exports = {
	isOwner: true,
	tag: 'Owner',
	models: '%prefix%command <text>',
	desc: 'Cambia el pie de los mensajes del bot.',
	cases: ['setfooter', 'footer', 'changefooter'],
	run: async(m, { chat, sock }) => {
		if (!m.text) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un texto para aplicar al final de los mensajes.\n\n*Ejemplo:* ${m.prefix+m.command} ${bot.name} by Nazi-team`);
			return;
		}

		chat.footer = m.text.trim();

		await m.react(react.owner);
		await m.reply('Se actulizo el footer de los mensajes.');
	}
}