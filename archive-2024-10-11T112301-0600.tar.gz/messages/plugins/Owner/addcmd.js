module.exports = {
	isOwner: true,
	tag: 'Owner',
	models: '%prefix%command <command>',
	desc: 'Añade un sticker para ejecutar comandos',
	cases: ['addcmd'],
	run: async(m, { sock }) => {
		if (!m.isQuoted || !/webp$/.test(m.quoted.mime) || !m.text) {
			await m.react(react.error);
			await m.reply(`🚩 Mencione un sticker y escriba el nombre del comando que quiere ejecutar con ese sticker.\n\n*Ejemplo:* ${m.prefix+m.command} kick`);
			return;

		}

		let plugin = plugins.filter((c) => c.cases && Array.isArray(c.cases)).map((c) => c.cases);
		let isFilteredCmd = plugin.some((v) => v.includes(m.query));

		if (!isFilteredCmd) {
			await m.react(react.error);
			await m.reply('🚩 Lo siento el comando que ingreso no corresponde a un comando dentro del bot, revise el menu.');
			return;
		};

		if ((m.quoted.sha256String in db.stickers)) {
			await m.react(react.error);
			await m.reply('🚩 Ese sticker ya esta seleccionado para otro comando. Para evitar conflictos use otro sticker diferente.', { quoted: m.quoted });
			return;
		};

		await m.react(react.wait);

		addFilter(m.sender);

		db.stickers[m.quoted.sha256String] = {
			command: m.query,
			prefix: m.prefix
		};

		await m.react(react.global);
		await m.reply('Se agrego el sticker a la lista de comandos.', { quoted: m.quoted });
	}
}