module.exports = {
	isOwner: true,
	tag: 'Owner',
	models: '%prefix%command <true|false>',
	desc: 'Activa o desactiva el uso de prefijos.',
	cases: ['prefix', 'noprefix', 'nonprefix'],
	run: async(m, { sock, chat }) => {
		await m.react(react.wait);

		addFilter(m.sender);

		switch(m.query) {
			case 'true':
				if (bot.usedPrefix) return m.reply('🚩 El bot ya tiene que usar prefijos para inciar los comandos.');

				bot.usedPrefix = true;

				await m.react(react.owner);
				await m.reply('Se activo el uso de prefijos. Los prefijos disponibles: ' + bot.prefix.map((a) => `[${a}]`).join(''));
			break;

			case 'false':
				if (!bot.usedPrefix) return m.reply('🚩 El bot no necesita prefijos para inciar los comandos.');

				bot.usedPrefix = false;

				await m.react(react.owner);
				await m.reply('Se desactivaron los prefijos. No es necesario poner un simbolo para inciar un comando.');
			break;

			default:
				await m.react(react.error);
				await m.replyButton({ type: 'list', buttonText: '📍 ¡Click Aqui! 📍', sections: [{ title: '', rows: [{ header: '• Desactivar prefijos', title: '', description: 'Usar comandos sin usar simbolos', id: `${m.prefix+m.command} false` }] }, { title: '', rows: [{ header: '• Activar prefijos', title: '', description: 'Utiliza simbolos para usar los comandos', id: `${m.prefix+m.command} true` }] }] }, { title: '🚩 ¿Desea activar o desactivar el uso de prefijos?', body: `\n*• Estado:* ${bot.usedPrefix ? 'Encendido' : 'Apagado'}`, footer: chat.footer });
		}
	}
}