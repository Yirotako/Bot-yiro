module.exports = {
	isOwner: true,
	tag: 'Owner',
	models: '%prefix%command <@group>',
	desc: 'Envia una lista de grupos de donde se puede salir.',
	cases: ['leave', 'salir'],
	run: async(m, { chat, sock }) => {

		await m.react(react.wait)

		addFilter(m.sender);
		
		if (/g\.us$/.test(m.text)) {
			if (!sock.chats[m.text]) {
				await m.react(react.error);
				await m.reply('🚩 El bot no se encuentra en ese grupo.');
				return;
			}

			await sock.groupLeave(sock.decodeJid(m.text));
			await m.reply('Se salio del grupo correctamente.', { from: m.sender });
			await m.react(react.owner);
		} else {
			let number = 1;
			let teks = '\t\t\t*「 ✦ Leave Groups ✦ 」*\n';
			let sections = [];
			let groups = Object.keys(sock.chats);
			let count = 0;

			for (let chat of groups) {
				let group = sock.chats[chat];
				let participants = group.participants.map((v) => sock.decodeJid(v.id));

				sections.push({
					title: `Grupo N° ${number++}`,
					rows: [{
						header: group.subject,
						title: '👥 Participantes: ' + participants.length,
						description: `${react.owner} Owner active: ` + participants.includes(owner[0].number + '@s.whatsapp.net'),
						id: `${m.prefix+m.command} ${chat}`
					}]
				});

				if (participants.includes(owner[0].number + '@s.whatsapp.net')) count += 1;
			}

			teks += `\n*❏ Total de grupos:* ${sections.length}\n`;
			teks += `\n*❏ Grupos available owner:* ${count}\n`;

			await m.react(react.global);
			await m.replyButton({ type: 'list', buttonText: '📍 ¡Click Aqui! 📍', sections }, { title: teks, footer: chat.footer });
		};
	}
}