module.exports = {
	isOwner: true,
	tag: 'Owner',
	models: '%prefix%command <sticker>',
	desc: 'Elimina un sticker de la lista de comandos.',
	cases: ['delcmd'],
	run: async(m, { sock }) => {
		if (!m.isQuoted || !/webp$/.test(m.quoted.mime)) {
			await m.react(react.error);
			await m.reply('🚩 Mencione un sticker para borrarlo de la base de datos.');
			return;
		}

		if (!(m.quoted.sha256String in db.stickers)) {
			await m.react(react.error);
			await m.reply('🚩 Lo siento el sticker que menciono parece no estar en la lista de comandos.');
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		delete db.stickers[m.quoted.sha256String];

		await m.react(react.owner);
		await m.reply('Se elimino el sticker de la base de datos con exito.');
	}
}