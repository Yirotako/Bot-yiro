module.exports = {
	isOwner: true,
	tag: 'Owner',
	models: '%prefix%command <prefijo>',
	desc: 'Agrega un prefijo a la lista de prefijos del bot.',
	cases: ['delprefix', 'deletepre', 'delprefa'],
	run: async(m, { settings }) => {
		if (!m.text || /[a-z0-9]/gi.test(m.text)) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un simbolo para quitar el prefijo.\n\n*Ejemplo:* ${m.prefix+m.command} !`);
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let index = bot.prefix.indexOf(m.text);

		if (index !== -1) {
			bot.prefix.splice(index, 1);
			await m.react(react.owner);
			await m.reply('Se elimino el prefijo [' + m.text + '] de la base de datos.');
		} else {
			await m.react(react.error);
			await m.reply('🚩 El prefijo que ingreso no esta en la base de datos.');
		};
	}
}