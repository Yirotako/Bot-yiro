const moment = require('moment-timezone');

module.exports = {
	isOwner: true,
	tag: 'Owner',
	models: '%prefix%command',
	desc: 'Muestra los grupos en donde esta el bot.',
	cases: ['listgp', 'totalgp'],
	run: async(m, { sock }) => {
		await m.react(react.wait);

		addFilter(m.sender);

		let groups = Object.values(sock.chats);

		let teks = '\t\t\t*「 ✦ Lista de Grupos ✦ 」*\n\n';

		for (let group of groups) {
			let members = group.participants.filter((v) => v.id.endsWith('@s.whatsapp.net')).map((v) => v.id.split('@')[0]);

			teks += `📛 *Nombre:* ${group.subject}\n`;
			teks += `👤 *Owner:* ${group.owner ? `@${group.owner.split('@')[0]}` : 'Sin creador'}\n`;
			teks += `⏳ *Creacion:* ${moment(group.creation * 1000).tz('America/Argentina/Mendoza').format('DD/MM/YYYY')}\n`;
			teks += `👥 *Participantes:* ${members.length}\n`;
			teks += `🎩 *Owner incluido:* ${owner.some((id) => members.includes(id)) ? 'Si' : 'No'}\n`;
			teks += `🌱 *ID:* ${group.id}\n`;
			teks += '\n────────────※ ·❆· ※────────────\n\n';
		}

		await m.reply(teks.trim());
		await m.react(react.global);
	}
}