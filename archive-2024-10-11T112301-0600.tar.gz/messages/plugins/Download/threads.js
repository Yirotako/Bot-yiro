module.exports = {
	tag: "Download",
	models: "%prefix%command <url>",
	desc: "Descarga video e imagenes de Threads.",
	cases: ["threads", "thdl", "th"],
	run: async(m) => {
		if (!m.bodyUrl || !/threads\.net\//i.test(m.bodyUrl)) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un link de Threads para descargar.\n\n*Ejemplo:* ${m.prefix+m.command} https://www.threads.net/XXXXX`);
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let { status, data, message } = await api.get("/api/download/threads", { url: m.bodyUrl });

		if (!status) {
			await m.react(react.error);
			await m.reply(`🚩 Error al realizar la descarga.`);
			return;
		}
		
		for (let { ext, link } of data) {
			switch (ext) {
				case 'mp4':
					await m.replyVid(link, { caption: mess['fake-video'], gif: false });
				break;

				case 'jpg':
				case 'png':
				case 'jpeg':
					await m.replyImg(link, { caption: mess['fake-image'] });
				break;
			}
		}

		await m.react(react.global);
	}
}