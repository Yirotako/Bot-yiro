module.exports = {
	tag: 'Download',
	models: '%prefix%command <url>',
	desc: 'Descargar una cancion de YouTube con una url que proveea el usuario.',
	cases: ['ytmp3'],
	run: async(m, { h2k, runtime }) => {
		if (!m.bodyUrl || !/youtube\.com(\/shorts)?|youtu\.be\//.test(m.bodyUrl)) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un link de YouTube para descargar.\n\n*Ejemplo:* ${m.prefix+m.command} https://youtube.com/watch?v=XXXXX`);
			return;
		}
		
		await m.react(react.wait);

		addFilter(m.sender);
		
		let { status, data, message } = await api.get('/download/youtube-audio', { url: m.bodyUrl });

		if (!status) {
			await m.react(react.error);
			await m.reply(`🚩 Error al realizar la descarga.`);
			return;
		}

		let teks = '\t\t\t*「 ✦ Download YouTube ✦ 」*\n\n';
		teks += `*⎔ Titulo:* ${data.title}\n`;
		teks += `*⎔ Autor:* ${data.author}\n`;
		teks += `*⎔ Duracion:* ${data.duration}\n`;
		teks += `*⎔ Calidad:* ${data.mp3.quality}\n`;
		teks += `*⎔ Peso:* ${data.mp3.size}\n\n`;
		teks += `> ${mess['fake-meta']}`;

		if (!/\-\-debug/gi.test(m.text)) await m.reply(teks, { ads: true, render: true, title: 'YouTube Download', body: `${fake.botText}`, image: data.thumbnail, link: m.bodyUrl });

		await m.replyAud(data.mp3.link, { ptt: false });
		await m.react(react.global);
	}
}