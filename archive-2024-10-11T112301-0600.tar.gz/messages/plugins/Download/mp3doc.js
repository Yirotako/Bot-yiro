module.exports = {
	tag: 'Download',
	models: '%prefix%command <url>',
	desc: 'Descarga un MP3 de YouTube con una url, en formato documento.',
	cases: ['mp3doc', 'ytmp3doc'],
	run: async(m, { h2k, runtime, resizeImg }) => {
		if (!m.bodyUrl || !/youtube\.com(\/shorts)?|youtu\.be\//.test(m.bodyUrl)) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un link de YouTube para descargar.\n\n*Ejemplo:* ${m.prefix+m.command} https://youtube.com/watch?v=XXXXX`);
			return;
		}
		
		await m.react(react.wait);

		addFilter(m.sender);
		
		let { status, data, message } = await api.get('/download/youtube-audio', { url: m.bodyUrl });

		if (!status) {
			await m.react(react.error);
			await m.reply(`🚩 Error al realizar la descarga.`);
			return;
		}

		let { image } = await resizeImg(data.thumbnail, 200);
		let teks = '\t\t\t*「 ✦ Download YouTube ✦ 」*\n\n';

		teks += `*⎔ Titulo:* ${data.title}\n`;
		teks += `*⎔ Autor:* ${data.author}\n`;
		teks += `*⎔ Duracion:* ${data.duration}\n`;
		teks += `*⎔ Calidad:* ${data.mp3.quality}\n`;
		teks += `*⎔ Peso:* ${data.mp3.size}\n\n`;
		teks += `> ${mess['fake-meta']}`;

		await m.replyDoc(data.mp3.link, { isDoc: true, jpeg: image.toString('base64'), caption: teks, filename: `${data.title.replace(/\//g, '').trim()}.mp3` });
		await m.react(react.global);
	}
}