module.exports = {
	tag: 'Download',
	models: '%prefix%command <url>',
	desc: 'Descarga video e imagenes de Instagram',
	cases: ['instagram', 'igdl', 'ig'],
	run: async(m) => {
		if (!m.bodyUrl || !/instagram\.com\/(p|reels?|tv)\//i.test(m.bodyUrl)) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un link de Instagram para descargar.\n\n*Ejemplo:* ${m.prefix+m.command} https://www.instagram.com/XXXXX`);
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let { status, data, message } = await api.get('/api/download/instagram', { url: m.bodyUrl });

		if (!status) {
			await m.react(react.error);
			await m.reply(`🚩 Error al realizar la descarga.`);
			return;
		}
		
		for (let { url, type } of data.media) {
			switch (type) {
				case 'video':
					await m.replyVid(url, { caption: mess['fake-video'], gif: false });
				break;

				case 'image':
					await m.replyImg(url, { caption: mess['fake-image'] });
				break;
			}
		}

		await m.react(react.global);
	}
}