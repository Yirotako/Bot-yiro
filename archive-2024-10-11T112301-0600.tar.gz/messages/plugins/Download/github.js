module.exports = {
	tag: 'Download',
	models: '%prefix%command <url>',
	desc: 'Descarga repositorios de Github en formato zip.',
	cases: ['gitclone', 'git-pull', 'git'],
	run: async(m, { chat }) => {
		if (!m.bodyUrl || !/github\.com\//i.test(m.bodyUrl)) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un link de Github para descargar.\n\n*Ejemplo:* ${m.prefix+m.command} https://github.com/XXXXX`);
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let { status, data, message } = await api.get('/api/download/github', { url: m.bodyUrl });

		if (!status) {
			await m.react(react.error);
			await m.reply(`🚩 Error al realizar la descarga.`);
			return;
		}

		let teks = '\t\t\t*「 ✦ Git Clone ✦ 」*\n\n';
		teks += `*⎔ Nombre:* ${data.title}\n`;
		teks += `*⎔ Author:* ${data.author}\n`;
		teks += `*⎔ Lenguaje:* ${data.language}\n`;
		teks += `*⎔ Peso:* %size\n`;
		teks += `*⎔ Descripcion:* ${data.description}\n\n`;
		teks += `> ${mess['fake-meta']}`;

		await m.react(react.global);
		await m.replyDoc(data.link, { caption: teks, filename: data.output, mimetype: data.mimetype });
	}
}