module.exports = {
	tag: 'Download',
	models: '%prefix%command <url>',
	desc: 'Descarga videos de Facebook (cuando no son privados).',
	cases: ['facebook', 'fbdl', 'fb'],
	run: async(m) => {
		if (!m.bodyUrl || !/facebook\.com|fb\.watch/i.test(m.bodyUrl)) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese un link de Facebook para descargar.\n\n*Ejemplo:* ${m.prefix+m.command} https://fb.watch/XXXXX`);
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		let { status, message, data } = await api.get('/api/download/facebookv3', { url: m.bodyUrl });

		if (!status) {
			await m.react(react.error);
			await m.reply(`🚩 Error al realizar la descarga.`);
			return;
		}

		let response = data?.metadata || data;
		let result = Array.isArray(response) ? response.find((value) => value.quality === 'HD' || value.quality === 'SD') : (response.hd ? response.hd : response.sd);

		await m.react(react.global);
		await m.replyVid(result, { caption: mess['fake-video'], gif: false });
	}
}