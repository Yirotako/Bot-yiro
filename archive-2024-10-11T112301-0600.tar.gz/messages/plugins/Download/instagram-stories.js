module.exports = {
	tag: 'Download',
	models: '%prefix%command <url o username>',
	desc: 'Descarga historias de instagram de un perfil publico.',
	cases: ['instagramh', 'instahdl', 'ighdl'],
	run: async(m) => {
		if (!m.bodyUrl || /instagram\.com\/(p|reels?|tv)\//.test(m.bodyUrl)) {
			await m.react(react.error);
			await m.reply(`🚩 Ingrese una url del perfil del usuario o de la historia para descargar.\n\n*Ejemplo 1:* ${m.prefix+m.command} https://www.instagram.com/stories/nikorasu_gzz\n*Ejemplo 2:* ${m.prefix+m.command} https://www.instagram.com/nikorasu_gzz`);
			return;
		}

		await m.react(react.wait);

		addFilter(m.sender);

		m.bodyUrl = m.bodyUrl.includes('stories') ? m.bodyUrl : 'https://www.instagram.com/stories/' + m.bodyUrl.replace('https://www.instagram.com/', '').replace(/\?.*$/g, '');

		let { status, data, message } = await api.get('/api/download/instagram/stories', { url: m.bodyUrl });

		if (!status) {
			await m.react(react.error);
			await m.reply(`🚩 Error al realizar la descarga.`);
			return;
		}
		
		for (let { url, type } of data.media) {
			switch (type.toLowerCase()) {
				case 'video':
					await m.replyVid(url, { caption: mess['fake-video'], gif: false });
				break;

				case 'image':
					await m.replyImg(url, { caption: mess['fake-image'] });
				break;
			}
		}

		await m.react(react.global);

	}
}