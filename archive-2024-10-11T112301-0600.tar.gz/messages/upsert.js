const fs = require('fs');
const { format } = require('util');
const syntaxErr = require('syntax-error');
const writedb = require('../lib/writedb');
const Stickers = require('../lib/stickers');
const Function = require('../lib/functions');
const TicTacToe = require('../lib/tictactoe');

module.exports = async (sock, m) => {
	try {
		if (m.isBot) return;

		await writedb(sock, m);

		let chat = db.chats[m.from] || {};
		let user = db.users[m.sender] || {};
		let group = sock.chats[m.from] || {};
		let settings = db.bot[m.botNumber] || {};
		let isBlock = !m.isOwner ? sock.blockList.includes(m.sender) : false;

		if (!m.fromMe) console.log(`\n┏━━━━━━━━━┅┅┄┄⟞⟦ ${bot.name} ⟝┄┄┉┉━━━━━━━━━┓\n┃ Number: +${m.senderNumber}\n┃ NickName: ${m.pushName}\n┃ messageType: ${m.type}${m.text ? `\n┃ messageContent: ${m.text}` : ''}${m.text ? `\n┃ messageLength: ${m.text.length}` : ''}${m.command ? `\n┃ Command: ${m.command}`: ''}${m.isGroup ? `\n┃ Group: ${group.subject}`: `\n┃ Privado: ${m.from}`}\n┗━━━━━━━━┅┅┄┄⟞⟦ ${bot.name} ⟧⟝┄┄┉┉━━━━━━━━┛`.trim());

		for (let plugin of plugins.filter((v) => !settings.unavailable.includes(v.name) && !chat?.unavailable?.includes(v.name))) {
			if (!plugin) continue;

			if (isBlock) continue;
			if (chat.mute && !m.isOwner) continue;

			let __arguments = { sock, settings, user, chat, group, v: m.isQuoted ? m.quoted : m, ...Function, ...Stickers, TicTacToe };
			let isCommand = plugin.cases ? (Array.isArray(plugin.cases) ? plugin.cases.includes(m.command) : plugin.cases.test(m.query)) : undefined;

			if (plugin.start && typeof plugin.start === 'function' && !isCommand) {
				if (user?.isBan) continue;
				if (plugin.isGroup && !m.isGroup) continue;
				if (plugin.isAdmin && !m.isAdmin) continue;
				if (plugin.isOwner && !m.isOwner) continue;
				if (plugin.isBotAdmin && !m.isBotAdmin) continue;

				try {
					await plugin.start.call(this, m, __arguments);
				} catch(e) {
					console.error(format(e));
				};
			};

			if (plugin.run && typeof plugin.run === 'function' && isCommand) {
				if (isFilter(m.sender)) { await m.react(react.clock); continue; };

				if (user?.ban && !m.isOwner) continue;
				if (plugin.isOwner && !m.isOwner) continue;

				if (plugin.isNsfw && !chat.nsfw) { await m.react(react.error); await m.reply(mess.nsfw); continue; }
				if (plugin.isAdmin && !m.isAdmin) { await m.react(react.error); await m.reply(mess.admin); continue; };
				if (plugin.isGroup && !m.isGroup) { await m.react(react.error); await m.reply(mess.onlygp); continue; };
				if (plugin.isVerify && !user.verify) { await m.react(react.error); await m.reply(mess.verify); continue; };
				if (plugin.isBotAdmin && !m.isBotAdmin) { await m.react(react.error); await m.reply(mess.adminBot); continue; };

				await sock.readMessages([m.key]);

				try {
					await plugin.run.call(this, m, __arguments);
				} catch(e) {
					console.error(format(e));
				};
			};
		};
	} catch(e) {
		console.error(format(e));
	};
};

let file = require.resolve(__filename);

fs.watchFile(file, () => {
	fs.unwatchFile(file);
	console.info(`Se actuliazo: upsert.js`);

	delete require.cache[file];

	require(file);
});