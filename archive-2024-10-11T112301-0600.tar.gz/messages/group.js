const fs = require('fs');
const { format } = require('util');
const { parsePhoneNumber } = require('libphonenumber-js');

module.exports = async (sock, m) => {
	try {
		if (m.isMe) return;

		let chat = db.chats[m.from] || {};
		let group = sock.chats[m.from] || {};

		if (chat.antifake && chat.fakelist.length > 0) {
			let phoneNumber = await parsePhoneNumber(`+${m.memberNumber}`);
			let isFakeNumber = chat.fakelist.some((prefijo) => phoneNumber.number.startsWith(prefijo));

			if (isFakeNumber && m.isBotAdmin && m.action === 'GROUP_PARTICIPANT_ADD') {
				await m.reply(`🚩 Su prefijo (+${phoneNumber.countryCallingCode}) no tiene permito ingresar a este grupo.`);
				await m.delay(3000);
				await sock.groupParticipantsUpdate(m.from, [m.member], 'remove');

				return;
			};
		};

		switch (m.action) {
			/// PARTICIPANT

			case 'GROUP_PARTICIPANT_ADD': {
				if (!chat.welcome) return;

				let teks = chat.welText.replace(/\@(usuario|user)/g, `@${m.memberNumber}`).replace(/\@(group|grupo)/g, group.subject).replace(/\@(desc|descripcion|description)/g, group.desc).replace(/\@(bot|botcito)/g, bot.name);
				let avatar = await sock.profilePictureUrl(m.member, 'image').catch(() => chat['render-template']);
				let counter = group?.participants?.map((v) => v.id).length;

				teks += `\n\n> ${mess['fake-bot']}`;

				await m.reply(teks.trim(), {
					ads: true,
					render: true,
					adAttrib: false,
					title: '¡Welcome Detection!',
					body: `Participante: #${counter + 1}`,
					image: avatar
				});
			};
			break;

			case 'GROUP_PARTICIPANT_LEAVE': case 'GROUP_PARTICIPANT_REMOVE': {
				if (!chat.welcome) return;

				let teks = chat.byeText.replace(/\@(usuario|user)/g, `@${m.memberNumber}`).replace(/\@(group|grupo)/g, group.subject).replace(/\@(desc|descripcion|description)/g, group.desc).replace(/\@(bot|botcito)/g, bot.name);
				let avatar = await sock.profilePictureUrl(m.member, 'image').catch(() => chat['render-template']);
				let counter = group?.participants?.map((v) => v.id).length;

				teks += `\n\n> ${mess['fake-bot']}`;

				await m.reply(teks.trim(), {
					ads: true,
					render: true,
					adAttrib: false,
					title: '¡Exit Detection!',
					body: `Participante: #${counter}`,
					image: avatar
				});
			};
			break;

			/// CHANGE GROUP

			case 'GROUP_PARTICIPANT_DEMOTE': {
				if (!chat.notify) return;

				let icon = await sock.profilePictureUrl(m.member, 'image').catch(() => 'https://telegra.ph/file/ded5d7ba34a696cc4d325.jpg');
				let teks = `\t\t\t*「 ✦ Nuevo Admin Degradado ✦ 」*\n\n*• Participante:* @${m.memberNumber}\n*• Admin:* @${m.senderNumber}\n*• Grupo:* ${group.subject}\n\n*_Este mensaje se emitio para evitar el RAID y cambios en el grupo_*\n\n> ${mess['fake-bot']}`;

				await m.reply(teks, {
					ads: true,
					render: true,
					adAttrib: false,
					mentions: [...m.admins, m.member],
					title: '¡DEMOTE DETECTION!',
					body: `Admin: #${m.admins.length - 1}`,
					image: icon
				});
			};
			break;

			case 'GROUP_PARTICIPANT_PROMOTE': {
				if (!chat.notify) return;

				let icon = await sock.profilePictureUrl(m.member, 'image').catch(() => 'https://telegra.ph/file/ded5d7ba34a696cc4d325.jpg');
				let teks = `\t\t\t*「 ✦ Nuevo Admin ✦ 」*\n\n*• Participante:* @${m.memberNumber}\n*• Admin:* @${m.senderNumber}\n*• Grupo:* ${group.subject}\n\n*_Este mensaje se emitio para evitar el RAID y cambios en el grupo_*\n\n> ${mess['fake-bot']}`;

				await m.reply(teks, {
					ads: true,
					render: true,
					adAttrib: false,
					mentions: [...m.admins, m.member],
					title: '¡PROMOTE DETECTION!',
					body: `Admin: #${m.admins.length + 1}`,
					image: icon
				});
			};
			break;

			case 'GROUP_CHANGE_ICON': {
				if (!chat.notify) return;

				let icon = await sock.profilePictureUrl(m.from, 'image').catch(() => 'https://telegra.ph/file/ded5d7ba34a696cc4d325.jpg');
				let teks = `\t\t\t*「 ✦ Nueva Accion ✦ 」*\n\n*• Participante:* @${m.memberNumber}\n*• Grupo:* ${group.subject}\n*• Cambio:* Icono del grupo\n\n*_Este mensaje se emitio para evitar el RAID y cambios en el grupo_*\n\n> ${mess['fake-bot']}`;

				await m.reply(teks, {
					ads: true,
					render: true,
					mentions: [...m.admins, m.member],
					title: '¡CHANGE DETECTION!',
					body: '',
					image: icon
				});
			};
			break;

			case 'GROUP_CHANGE_SUBJECT': {
				if (!chat.notify) return;

				let icon = await sock.profilePictureUrl(m.from, 'image').catch(() => 'https://telegra.ph/file/ded5d7ba34a696cc4d325.jpg');
				let teks = `\t\t\t*「 ✦ Nueva Accion ✦ 」*\n\n*• Participante:* @${m.memberNumber}\n*• Grupo:* ${group.subject}\n*• Cambio:* Nombre del grupo\n\n*_Este mensaje se emitio para evitar el RAID y cambios en el grupo_*\n\n> ${mess['fake-bot']}`;

				await m.reply(teks, {
					ads: true,
					render: true,
					mentions: [...m.admins, m.member],
					title: '¡CHANGE DETECTION!',
					body: '',
					image: icon
				});
			}
			break;

			case 'GROUP_MEMBERSHIP_JOIN_APPROVAL_MODE': {
				if (!chat.notify) return;

				let icon = await sock.profilePictureUrl(m.from, 'image').catch(() => 'https://telegra.ph/file/ded5d7ba34a696cc4d325.jpg');
				let teks = `\t\t\t*「 ✦ Nueva Accion ✦ 」*\n\n*• Participante:* @${m.memberNumber}\n*• Grupo:* ${group.subject}\n*• Cambio:* Aprovacion de participantes\n\n*_Este mensaje se emitio para evitar el RAID y cambios en el grupo_*\n\n> ${mess['fake-bot']}`;

				await m.reply(teks, {
					ads: true,
					render: true,
					mentions: [...m.admins, m.member],
					title: '¡CHANGE DETECTION!',
					body: '',
					image: icon
				});
			};
			break;

			case 'GROUP_CHANGE_ANNOUNCE': {
				if (!chat.notify) return;

				let icon = await sock.profilePictureUrl(m.from, 'image').catch(() => 'https://telegra.ph/file/ded5d7ba34a696cc4d325.jpg');
				let teks = `\t\t\t*「 ✦ Nueva Accion ✦ 」*\n\n*• Participante:* @${m.memberNumber}\n*• Grupo:* ${group.subject}\n*• Cambio:* Abrir/Cerrar el grupo\n\n*_Este mensaje se emitio para evitar el RAID y cambios en el grupo_*\n\n> ${mess['fake-bot']}`;

				await m.reply(teks, {
					ads: true,
					render: true,
					mentions: [...m.admins, m.member],
					title: '¡CHANGE DETECTION!',
					body: '',
					image: icon
				});
			};
			break;

			case 'GROUP_CHANGE_RESTRICT': {
				if (!chat.notify) return;

				let icon = await sock.profilePictureUrl(m.from, 'image').catch(() => 'https://telegra.ph/file/ded5d7ba34a696cc4d325.jpg');
				let teks = `\t\t\t*「 ✦ Nueva Accion ✦ 」*\n\n*• Participante:* @${m.memberNumber}\n*• Grupo:* ${group.subject}\n*• Cambio:* Ajustes del grupo\n\n*_Este mensaje se emitio para evitar el RAID y cambios en el grupo_*\n\n> ${mess['fake-bot']}`;

				await m.reply(teks, {
					ads: true,
					render: true,
					mentions: [...m.admins, m.member],
					title: '¡CHANGE DETECTION!',
					body: '',
					image: icon
				});
			};
			break;

			case 'GROUP_MEMBER_ADD_MODE': {
				if (!chat.notify) return;

				let icon = await sock.profilePictureUrl(m.from, 'image').catch(() => 'https://telegra.ph/file/ded5d7ba34a696cc4d325.jpg');
				let teks = `\t\t\t*「 ✦ Nueva Accion ✦ 」*\n\n*• Participante:* @${m.memberNumber}\n*• Grupo:* ${group.subject}\n*• Cambio:* Agregar participantes\n\n*_Este mensaje se emitio para evitar el RAID y cambios en el grupo_*\n\n> ${mess['fake-bot']}`;

				await m.reply(teks, {
					ads: true,
					render: true,
					mentions: [...m.admins, m.member],
					title: '¡CHANGE DETECTION!',
					body: '',
					image: icon
				});
			};
			break;
		}
	} catch(e) {
		console.error(format(e));
	}
}

let file = require.resolve(__filename);

fs.watchFile(file, () => {
	fs.unwatchFile(file);
	console.info(`Se actuliazo: group.js`);

	delete require.cache[file];

	require(file);
});